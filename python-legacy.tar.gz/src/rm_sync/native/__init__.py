"""Platform-native integration helpers. macOS-only for v0.1."""
