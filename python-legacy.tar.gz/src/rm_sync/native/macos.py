"""macOS-native polish for pulled docs.

Three things live here:

1. Extended attributes written onto every pulled .md so Finder and
   Spotlight treat it as coming from the reMarkable cloud.
2. A Finder folder icon installer for the sync directory.
3. A user-facing notification helper (via ``osascript``) so conflicts
   don't disappear into a silent ``.conflict`` file.

Everything is best-effort: if a call fails (non-macOS host, permission
issue, etc.) we log and continue. The state DB remains authoritative —
these are garnish, not guarantees.
"""

from __future__ import annotations

import ctypes
import ctypes.util
import json
import os
import plistlib
import shutil
import struct
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from rm_sync.logging_setup import get

log = get(__name__)

# macOS libc bindings. ``os.setxattr`` / ``os.getxattr`` are Linux-only;
# macOS's equivalents live in libc with a different (position, options)
# signature. Loading lazily so non-Darwin hosts don't choke.
if sys.platform == "darwin":
    _libc = ctypes.CDLL(ctypes.util.find_library("c"), use_errno=True)
    # int setxattr(const char *path, const char *name, const void *value,
    #              size_t size, u_int32_t position, int options);
    _libc.setxattr.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_size_t,
        ctypes.c_uint32,
        ctypes.c_int,
    ]
    _libc.setxattr.restype = ctypes.c_int
    # ssize_t getxattr(const char *path, const char *name, void *value,
    #                  size_t size, u_int32_t position, int options);
    _libc.getxattr.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_size_t,
        ctypes.c_uint32,
        ctypes.c_int,
    ]
    _libc.getxattr.restype = ctypes.c_ssize_t
else:
    _libc = None  # type: ignore[assignment]


def _setxattr(path: Path, name: str, value: bytes) -> None:
    if _libc is None:
        return
    rc = _libc.setxattr(
        os.fsencode(str(path)),
        name.encode("utf-8"),
        value,
        len(value),
        0,  # position: always 0 for non-resource-fork xattrs
        0,  # options: XATTR_NOFOLLOW=0x1; we want to follow symlinks
    )
    if rc != 0:
        err = ctypes.get_errno()
        raise OSError(err, os.strerror(err), str(path))


def _getxattr(path: Path, name: str) -> bytes:
    if _libc is None:
        raise OSError(0, "xattr not supported on this platform", str(path))
    # First call with size=0 returns the actual size.
    size = _libc.getxattr(
        os.fsencode(str(path)), name.encode("utf-8"), None, 0, 0, 0
    )
    if size < 0:
        err = ctypes.get_errno()
        raise OSError(err, os.strerror(err), str(path))
    buf = ctypes.create_string_buffer(size)
    read = _libc.getxattr(
        os.fsencode(str(path)), name.encode("utf-8"), buf, size, 0, 0
    )
    if read < 0:
        err = ctypes.get_errno()
        raise OSError(err, os.strerror(err), str(path))
    return buf.raw[:read]

# xattr names -------------------------------------------------------------

_WHERE_FROMS = "com.apple.metadata:kMDItemWhereFroms"
_KIND = "com.apple.metadata:kMDItemKind"
_TAGS = "com.apple.metadata:_kMDItemUserTags"
_FINDER_INFO = "com.apple.FinderInfo"

# Finder tag colour ids: 0=none, 1=grey, 2=green, 3=purple, 4=blue,
# 5=yellow, 6=red, 7=orange. Yellow feels right for "synced from a
# yellow-tinted tablet".
_TAG_NAME = "reMarkable"
_TAG_COLOUR = 5


# ---- Metadata for pulled files ----------------------------------------------


@dataclass
class FileMetadata:
    """Metadata we write to a pulled .md. All fields optional; we skip
    any whose value is falsy."""

    doc_id: str | None = None
    remote_path: str | None = None
    remote_modified: str | None = None
    page_ids: list[str] | None = None


def apply_metadata(path: Path, meta: FileMetadata) -> None:
    """Write our xattr set onto ``path``. Best-effort; logs on failure.

    Called right after a successful pull — the worker holds the per-doc
    lock, so there's no race with a concurrent edit.
    """
    if sys.platform != "darwin":
        return
    try:
        _set_where_froms(path, meta)
        _set_kind(path)
        _set_tag(path, _TAG_NAME, _TAG_COLOUR)
        if meta.doc_id:
            _set_plain(path, "rm-sync.doc_id", meta.doc_id)
        if meta.remote_path:
            _set_plain(path, "rm-sync.remote_path", meta.remote_path)
        if meta.remote_modified:
            _set_plain(path, "rm-sync.remote_modified", meta.remote_modified)
        if meta.page_ids:
            _set_plain(path, "rm-sync.page_ids", json.dumps(meta.page_ids))
    except Exception as e:
        log.debug("apply_metadata failed", path=str(path), error=str(e))


def _set_where_froms(path: Path, meta: FileMetadata) -> None:
    """kMDItemWhereFroms is a binary plist array of strings. Finder's
    Get Info panel surfaces the first-second pair as "Where from"."""
    entries: list[str] = ["reMarkable Cloud"]
    if meta.remote_path:
        entries.append(meta.remote_path)
    blob = plistlib.dumps(entries, fmt=plistlib.FMT_BINARY)
    _setxattr(path, _WHERE_FROMS, blob)


def _set_kind(path: Path) -> None:
    blob = plistlib.dumps("reMarkable Notebook", fmt=plistlib.FMT_BINARY)
    _setxattr(path, _KIND, blob)


def _set_tag(path: Path, name: str, colour: int) -> None:
    """Finder user tags are a bplist array of "<name>\\n<colour>" strings."""
    entry = f"{name}\n{colour}"
    blob = plistlib.dumps([entry], fmt=plistlib.FMT_BINARY)
    _setxattr(path, _TAGS, blob)


def _set_plain(path: Path, name: str, value: str) -> None:
    _setxattr(path, name, value.encode("utf-8"))


def read_doc_id(path: Path) -> str | None:
    """Return the ``rm-sync.doc_id`` xattr if present, else None.

    Handy for troubleshooting — can answer "which reMarkable doc is
    this file, even if I renamed it?" without touching the state DB.
    """
    if sys.platform != "darwin":
        return None
    try:
        return _getxattr(path, "rm-sync.doc_id").decode("utf-8")
    except OSError:
        return None


# ---- Folder icon ------------------------------------------------------------

# 32-byte FolderInfo/FileInfo structure. We only need the flag bits at
# offset 8-9 (big-endian u16). Bit 0x0400 = kHasCustomIcon (folder), bit
# 0x4000 = kIsInvisible (file). The rest stays zero.
_FOLDER_INFO_CUSTOM_ICON = struct.pack(">8sH22s", b"\x00" * 8, 0x0400, b"\x00" * 22)
_FILE_INFO_INVISIBLE = struct.pack(">8sH22s", b"\x00" * 8, 0x4000, b"\x00" * 22)


def ensure_folder_icon(folder: Path, icns_src: Path | None = None) -> None:
    """Install a custom Finder icon on ``folder``.

    Layout Finder expects:
      folder/Icon?            (the literal filename 'Icon\\r')
      folder/Icon?.xattr      com.apple.FinderInfo with kIsInvisible set
      folder xattr             com.apple.FinderInfo with kHasCustomIcon set

    Idempotent: if the sentinel xattr is already present and the
    ``Icon\\r`` file exists, returns without touching disk.
    """
    if sys.platform != "darwin":
        return
    try:
        if _folder_icon_already_set(folder):
            return
        src = icns_src or _bundled_icon()
        if src is None or not src.exists():
            log.debug("folder icon asset missing; skipping", folder=str(folder))
            return

        icon_file = folder / "Icon\r"
        shutil.copyfile(src, icon_file)
        _setxattr(icon_file, _FINDER_INFO, _FILE_INFO_INVISIBLE)
        _setxattr(folder, _FINDER_INFO, _FOLDER_INFO_CUSTOM_ICON)
        log.info("folder icon installed", folder=str(folder))
    except Exception as e:
        log.debug("ensure_folder_icon failed", folder=str(folder), error=str(e))


def _folder_icon_already_set(folder: Path) -> bool:
    if not (folder / "Icon\r").exists():
        return False
    try:
        info = _getxattr(folder, _FINDER_INFO)
    except OSError:
        return False
    # Bit 0x0400 at offset 8-9 big-endian
    if len(info) < 10:
        return False
    flags = struct.unpack(">H", info[8:10])[0]
    return bool(flags & 0x0400)


def _bundled_icon() -> Path | None:
    """Locate ``assets/folder-icon.icns`` inside the installed package."""
    # The package installs with ``pip install -e .`` so ``__file__`` lives
    # under ``<repo>/src/rm_sync/native/macos.py``. The asset sits at
    # ``<repo>/assets/folder-icon.icns``.
    here = Path(__file__).resolve()
    candidate = here.parent.parent.parent.parent / "assets" / "folder-icon.icns"
    return candidate if candidate.exists() else None


# ---- Notifications ----------------------------------------------------------


def notify(title: str, body: str, *, subtitle: str | None = None) -> None:
    """Fire a Notification Center banner via osascript. Best-effort."""
    if sys.platform != "darwin":
        return
    script_parts = [f'display notification {_ascript_quote(body)}']
    script_parts.append(f"with title {_ascript_quote(title)}")
    if subtitle:
        script_parts.append(f"subtitle {_ascript_quote(subtitle)}")
    script = " ".join(script_parts)
    try:
        subprocess.run(
            ["osascript", "-e", script],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except Exception as e:
        log.debug("notify failed", error=str(e))


def notify_conflict(doc_title: str, local_path: Path) -> None:
    notify(
        title="rm-sync: conflict",
        body=f"{doc_title} changed on both sides. A .conflict file was written.",
        subtitle=str(local_path.parent),
    )


def _ascript_quote(s: str) -> str:
    """Quote a string for inlining into an AppleScript string literal."""
    escaped = s.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'
