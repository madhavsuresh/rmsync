"""SyncWorker — pull/push executor.

Pull sequence:
  1. Acquire per-doc lock.
  2. Skip if conflict_state='unresolved' AND .conflict file present.
  3. ``rmapi get`` → unpack .rmdoc → rm_to_md per page → join_pages.
  4. Compare new_md_hash to last_synced_md_hash:
       - equal: no-op (drop spurious pull).
       - local file matches stored hash (clean local): write new file via
         atomic_write_text, mark fence, mark_pulled.
       - local file changed since last sync: CONFLICT — write .conflict,
         set conflict_state='unresolved'.

Push sequence (verified against real cloud in scripts/cloud_probe2.py):
  1. Acquire per-doc lock.
  2. Skip if conflict_state='unresolved' AND .conflict file present.
  3. Read local .md, hash. If hash == last_synced_md_hash, skip (echo).
  4. Build .rmdoc reusing doc_id (cloud honors the packed ID).
  5. ``rmapi put`` (new doc) or ``rmapi put --force`` (update in place).
  6. Re-stat to capture new ModifiedClient; record in state.
  7. Strategy B only: re-download, parse, compare; if mismatch park doc.

The spec's ``--content-only`` is PDF-only and was the wrong flag; ``--force``
is the right one for .rmdoc updates. Document UUID is stable across
``put --force`` updates (verified).
"""

from __future__ import annotations

import asyncio
import hashlib
import shutil
import tempfile
import time
import uuid
from pathlib import Path

from rm_sync.cloud import Cloud, RmapiError, RmapiThrottled
from rm_sync.config import Config
from rm_sync.conflict import (
    conflict_path_for,
    has_unresolved_conflict_file,
    write_conflict,
)
from rm_sync.conversion import archive, md_to_rm, page_splitter, rm_to_md
from rm_sync.echo_fence import EchoFence
from rm_sync.jobs import Job, JobKind
from rm_sync.locks import LockRegistry
from rm_sync.logging_setup import get
from rm_sync.paths import atomic_write_text, normalize_for_compare
from rm_sync.state import Document, State

log = get(__name__)

# §16 question 1 resolved via real-cloud probe: ``put --force`` updates in
# place, doc UUID is stable, content round-trips. Push path is live.
SAFE_PUSH_VERIFIED = True


_UUID_RE = __import__("re").compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$"
)


def _looks_like_uuid(s: str) -> bool:
    return bool(_UUID_RE.match(s.lower()))


def _sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


class SyncWorker:
    def __init__(
        self,
        worker_id: int,
        queue: asyncio.Queue[Job],
        cloud: Cloud,
        state: State,
        cfg: Config,
        locks: LockRegistry,
        fence: EchoFence,
    ):
        self.id = worker_id
        self.queue = queue
        self.cloud = cloud
        self.state = state
        self.cfg = cfg
        self.locks = locks
        self.fence = fence
        self._stop = asyncio.Event()

    def stop(self) -> None:
        self._stop.set()

    async def run(self) -> None:
        log.info("worker started", worker=self.id)
        while not self._stop.is_set():
            try:
                job = await asyncio.wait_for(self.queue.get(), timeout=1.0)
            except asyncio.TimeoutError:
                continue
            try:
                await self._dispatch(job)
            except RmapiThrottled as e:
                log.warning("worker throttled", worker=self.id, error=str(e))
                await asyncio.sleep(60)
                # Re-queue once
                await self.queue.put(job)
            except Exception:
                log.exception("worker job crashed", worker=self.id, job=job)
            finally:
                self.queue.task_done()
        log.info("worker stopped", worker=self.id)

    async def _dispatch(self, job: Job) -> None:
        if self.cfg.dry_run:
            log.info("dry-run skip", job=job)
            return

        if job.kind == JobKind.PULL and job.doc_id:
            async with self.locks.acquire(job.doc_id):
                await self._pull(job.doc_id, job.hint)
        elif job.kind == JobKind.PUSH:
            await self._push(job)
        elif job.kind == JobKind.DELETE_LOCAL:
            # Two callers:
            #   - poller (job.doc_id set): remote doc is gone; trash local.
            #   - watcher (job.doc_id None, hint set): local file went away;
            #     confirm and log, but never auto-delete remote in v0.1.
            if job.doc_id is not None:
                async with self.locks.acquire(job.doc_id):
                    await self._delete_local(job.doc_id)
            elif job.hint:
                stored = await self.state.by_local_path(job.hint)
                if stored is None:
                    log.debug("delete ignored: not tracked", hint=job.hint)
                    return
                async with self.locks.acquire(stored.doc_id):
                    await self._note_local_gone(stored.doc_id)
        elif job.kind == JobKind.RENAME_REMOTE and job.doc_id:
            async with self.locks.acquire(job.doc_id):
                await self._rename_local_to_match_remote(job.doc_id, job.hint)
        elif job.kind == JobKind.DELETE_REMOTE and job.doc_id:
            async with self.locks.acquire(job.doc_id):
                await self._delete_remote(job.doc_id)
        else:
            log.warning("unknown or invalid job", job=job)

    # ---- pull --------------------------------------------------------------

    async def _pull(self, doc_id: str, remote_path_hint: str) -> None:
        stored = await self.state.get(doc_id)
        local_path = (
            Path(stored.local_path) if stored else self._derive_local_path(remote_path_hint)
        )

        if stored and stored.conflict_state == "unresolved" and has_unresolved_conflict_file(local_path):
            log.info("pull skipped: unresolved conflict", doc_id=doc_id)
            return

        with tempfile.TemporaryDirectory(prefix="rmsync-") as tmpd:
            tmp = Path(tmpd)
            try:
                rmdoc_path = await self.cloud.get(remote_path_hint, tmp)
            except RmapiError as e:
                log.error("rmapi get failed", doc_id=doc_id, error=str(e))
                return

            try:
                rmdoc = archive.unpack(rmdoc_path)
            except Exception as e:
                log.error("rmdoc unpack failed", doc_id=doc_id, error=str(e))
                await self.state.set_error(doc_id, "parse_failed")
                return

            try:
                pages_md = [rm_to_md.page_to_markdown(p.rm_bytes) for p in rmdoc.pages]
            except rm_to_md.RmParseError as e:
                log.error("page parse failed; parking doc", doc_id=doc_id, error=str(e))
                if stored:
                    await self.state.set_error(doc_id, "parse_failed")
                return

        new_md = page_splitter.join_pages(pages_md) if pages_md else ""
        new_hash = _sha256_text(new_md)

        if stored and stored.last_synced_md_hash == new_hash:
            log.debug("pull no-op (hash unchanged)", doc_id=doc_id)
            return

        # Determine local-side state
        local_changed = False
        if local_path.exists() and stored is not None:
            current_hash = _sha256_file(local_path)
            if stored.last_synced_md_hash and current_hash != stored.last_synced_md_hash:
                local_changed = True

        if local_changed:
            local_text = local_path.read_text(encoding="utf-8")
            write_conflict(local_path, local=local_text, remote=new_md)
            await self.state.set_conflict(doc_id, "unresolved")
            log.warning("conflict written", doc_id=doc_id, path=str(local_path))
            try:
                from rm_sync.native import macos as _native

                _native.notify_conflict(rmdoc.visible_name or local_path.stem, local_path)
            except Exception:
                log.debug("conflict notification failed", doc_id=doc_id)
            return

        # Capture ModifiedClient from the cloud so the next poll doesn't
        # re-trigger this pull. rmdoc's metadata.lastModified is client-set
        # and not what the cloud returns via stat.
        meta = await self.cloud.stat(remote_path_hint)
        remote_modified = (meta or {}).get("ModifiedClient", "") if meta else ""

        # Write the new content atomically. Stamp xattrs with provenance
        # so Finder/Spotlight show the doc as "from reMarkable Cloud".
        from rm_sync.native.macos import FileMetadata as _FileMetadata

        file_meta = _FileMetadata(
            doc_id=doc_id,
            remote_path=remote_path_hint,
            remote_modified=remote_modified,
            page_ids=[p.page_id for p in rmdoc.pages],
        )
        self.fence.mark(normalize_for_compare(local_path))
        atomic_write_text(local_path, new_md, metadata=file_meta)

        doc = Document(
            doc_id=doc_id,
            parent_id=(stored.parent_id if stored else ""),
            doc_type="DocumentType",
            title=rmdoc.visible_name,
            remote_path=remote_path_hint,
            local_path=str(local_path),
            remote_version=rmdoc.version,
            remote_modified=remote_modified,
            last_synced_md_hash=new_hash,
            last_pull_at=None,  # mark_pulled stamps it
            last_push_at=stored.last_push_at if stored else None,
            conflict_state=None,
            error_state=None,
            # Record page UUIDs so the next push reuses them and keeps
            # sync15 cPages stable (no ghost entries).
            page_ids=[p.page_id for p in rmdoc.pages],
        )
        await self.state.upsert(doc)
        await self.state.mark_pulled(
            doc_id,
            version=rmdoc.version,
            md_hash=new_hash,
            modified=remote_modified,
        )
        log.info("pulled", doc_id=doc_id, path=str(local_path))

    # ---- push --------------------------------------------------------------

    async def _push(self, job: Job) -> None:
        if not SAFE_PUSH_VERIFIED:
            log.warning(
                "push gated until open-q1 verified; dropping job",
                hint=job.hint,
                see="cloud.py TODO(open-q1)",
            )
            return

        local_path = Path(job.hint)
        if not local_path.exists():
            log.debug("push ignored: file gone", path=str(local_path))
            return

        # Refuse to push from any location that isn't directly under sync_dir.
        # A file inside sync_dir/Writing/... is almost certainly residue
        # from a prior buggy pull; pushing it would create a cloud phantom.
        try:
            rel = local_path.relative_to(self.cfg.sync_dir)
        except ValueError:
            log.warning("push refused: path not in sync_dir", path=str(local_path))
            return
        if any(part.startswith(".") for part in rel.parts):
            return  # hidden dir; .rm-sync-trash etc.

        norm = normalize_for_compare(local_path)
        if self.fence.is_recent(norm):
            log.debug("push echo-suppressed", path=norm)
            return

        # Look up by local path. If unknown, this is a brand-new doc.
        stored = await self.state.by_local_path(str(local_path))

        # Safety: if the filename looks like a UUID and we have no stored
        # row for it, it's almost certainly the tail of a pull-push cascade.
        # Refuse the push; the user will never have typed a UUID as a note
        # name on purpose.
        if stored is None and _looks_like_uuid(local_path.stem):
            log.warning(
                "push refused: new doc with UUID-like name (cascade guard)",
                stem=local_path.stem,
            )
            return

        if stored and stored.conflict_state == "unresolved":
            if has_unresolved_conflict_file(local_path):
                log.info("push skipped: unresolved conflict", doc_id=stored.doc_id)
                return
            # User resolved by deleting .conflict — proceed.
            await self.state.set_conflict(stored.doc_id, None)

        async with self.locks.acquire(stored.doc_id if stored else f"new:{norm}"):
            await self._do_push(local_path, stored)

    async def _do_push(self, local_path: Path, stored: Document | None) -> None:
        text = local_path.read_text(encoding="utf-8")
        new_hash = _sha256_text(text)

        if stored and stored.last_synced_md_hash == new_hash:
            log.debug("push no-op (hash unchanged)", doc_id=stored.doc_id)
            return

        # Stable author_uuid per install — see md_to_rm.page_native_plain
        # docstring and state.get_or_create_author_uuid.
        author_uuid = await self.state.get_or_create_author_uuid()

        pages_md = page_splitter.split_pages(text)
        if self.cfg.push_strategy == "native_plain":
            page_bytes = [
                md_to_rm.page_native_plain(p, author_uuid=author_uuid) for p in pages_md
            ]
        elif self.cfg.push_strategy == "native_formatted":
            page_bytes = [md_to_rm.page_native_formatted(p) for p in pages_md]
        elif self.cfg.push_strategy == "pdf":
            # PDFs are single-document, not page-split. Skip page splitting.
            log.warning("pdf push not yet wired into worker")
            return
        else:
            log.error("unknown push strategy", strategy=self.cfg.push_strategy)
            return

        doc_id = stored.doc_id if stored else str(uuid.uuid4())
        # Reuse page UUIDs for stable sync15 cPages. For extra pages beyond
        # what we previously tracked, mint new ids; for fewer pages, drop
        # the excess (the tablet will show the updated set).
        reuse_ids = list(stored.page_ids) if stored else []
        page_ids: list[str] = []
        for i in range(len(page_bytes)):
            if i < len(reuse_ids):
                page_ids.append(reuse_ids[i])
            else:
                page_ids.append(archive.new_page_id())
        rmdoc_pages = [
            archive.RmDocPage(page_id=pid, rm_bytes=b)
            for pid, b in zip(page_ids, page_bytes)
        ]
        next_version = (stored.remote_version + 1) if stored else 1
        # rmapi v0.0.32 uses the .rmdoc FILENAME as the cloud doc name, not
        # the packed ``visibleName``. If we name the archive by doc_id the
        # cloud ends up full of UUID-named phantoms. Always name by the
        # visible/local stem.
        visible = stored.title if stored else local_path.stem

        with tempfile.TemporaryDirectory(prefix="rmsync-") as tmpd:
            out = Path(tmpd) / f"{visible}.rmdoc"
            archive.pack(
                archive.RmDoc(
                    doc_id=doc_id,
                    visible_name=(stored.title if stored else local_path.stem),
                    pages=rmdoc_pages,
                    version=next_version,
                    last_modified=int(time.time() * 1000),
                ),
                out,
            )

            remote_parent = (
                stored.remote_path.rsplit("/", 1)[0]
                if stored
                else f"/{self.cfg.remote_folder}"
            )
            try:
                # `update=True` uses `rmapi put --force` which replaces the
                # existing doc by name, preserving its UUID.
                await self.cloud.put(out, remote_parent, update=bool(stored))
            except RmapiError as e:
                log.error("rmapi put failed", doc_id=doc_id, error=str(e))
                return

            # Re-stat to capture the cloud-assigned ModifiedClient so the
            # next poller cycle doesn't see this push as a remote change.
            remote_doc_path = (
                stored.remote_path
                if stored
                else f"{remote_parent}/{local_path.stem}"
            )
            meta = await self.cloud.stat(remote_doc_path)
            new_modified = (meta or {}).get("ModifiedClient", "") if meta else ""

        # Strategy B requires a round-trip validation step. Park on mismatch.
        if self.cfg.push_strategy == "native_formatted":
            ok = await self._validate_round_trip(doc_id, text)
            if not ok:
                await self.state.set_error(doc_id, "push_validation_failed")
                log.error("push validation failed; doc parked", doc_id=doc_id)
                return

        # New docs have no state row yet — insert one before marking pushed.
        if stored is None:
            from rm_sync.state import Document as _Doc

            await self.state.upsert(
                _Doc(
                    doc_id=doc_id,
                    parent_id="",
                    doc_type="DocumentType",
                    title=local_path.stem,
                    remote_path=remote_doc_path,
                    local_path=str(local_path),
                    remote_version=next_version,
                    remote_modified=new_modified,
                    last_synced_md_hash=new_hash,
                    page_ids=page_ids,
                )
            )
        else:
            # Update the page_ids list in case it grew/shrank this push.
            await self.state.set_page_ids(doc_id, page_ids)
        await self.state.mark_pushed(
            doc_id, version=next_version, md_hash=new_hash, modified=new_modified
        )
        log.info("pushed", doc_id=doc_id, path=str(local_path))

    async def _validate_round_trip(self, doc_id: str, expected_md: str) -> bool:
        """Re-download the just-pushed doc and compare. Strategy B safety net."""
        # Implementation deferred until strategy B writer exists.
        log.warning("round-trip validation requested but strategy B not implemented")
        return False

    # ---- deletions / renames ----------------------------------------------

    async def _note_local_gone(self, doc_id: str) -> None:
        """Watcher said a tracked local file was deleted.

        For v0.1 we do NOT propagate this to the cloud — FSEvents may
        replay events, the user may have rename-via-tmp'd, or some other
        tool may have touched the dir. Destructive cloud actions driven by
        a single watcher event are too risky without a rename-detection
        window. Just log at WARNING so the user can investigate.
        """
        stored = await self.state.get(doc_id)
        if stored is None:
            return
        if Path(stored.local_path).exists():
            log.debug("local delete discarded: file reappeared", doc_id=doc_id)
            return
        log.warning(
            "local delete detected; cloud removal deferred (safety, v0.1)",
            doc_id=doc_id,
            local_path=stored.local_path,
        )

    async def _delete_local(self, doc_id: str) -> None:
        stored = await self.state.get(doc_id)
        if stored is None:
            return
        local = Path(stored.local_path)
        if local.exists():
            trash = self.cfg.sync_dir / ".rm-sync-trash"
            trash.mkdir(parents=True, exist_ok=True)
            target = trash / local.name
            # Avoid clobber
            if target.exists():
                target = trash / f"{local.stem}-{uuid.uuid4().hex[:6]}{local.suffix}"
            shutil.move(str(local), str(target))
            log.info("local moved to trash", doc_id=doc_id, dest=str(target))
        await self.state.delete(doc_id)

    async def _delete_remote(self, doc_id: str) -> None:
        stored = await self.state.get(doc_id)
        if stored is None:
            return
        try:
            await self.cloud.rm(stored.remote_path)
        except RmapiError as e:
            log.error("remote delete failed", doc_id=doc_id, error=str(e))
            return
        await self.state.delete(doc_id)
        log.info("remote deleted", doc_id=doc_id)

    async def _rename_local_to_match_remote(self, doc_id: str, new_remote_path: str) -> None:
        stored = await self.state.get(doc_id)
        if stored is None:
            return
        new_local = self._derive_local_path(new_remote_path)
        old_local = Path(stored.local_path)
        if old_local.exists() and old_local != new_local:
            from rm_sync.paths import case_only_rename
            new_local.parent.mkdir(parents=True, exist_ok=True)
            try:
                case_only_rename(old_local, new_local)
            except OSError as e:
                log.error("local rename failed", doc_id=doc_id, error=str(e))
                return
        stored.local_path = str(new_local)
        stored.remote_path = new_remote_path
        await self.state.upsert(stored)
        log.info("local renamed to match remote", doc_id=doc_id, new_path=str(new_local))

    # ---- helpers -----------------------------------------------------------

    def _derive_local_path(self, remote_path: str) -> Path:
        from rm_sync.paths import remote_to_local

        return remote_to_local(remote_path, self.cfg.sync_dir, self.cfg.remote_folder)
