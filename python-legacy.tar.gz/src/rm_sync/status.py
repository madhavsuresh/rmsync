"""Periodic status snapshot writer for the menu bar app.

The Swift menu bar app (``menubar/``) reads this JSON file and watches
it with ``DispatchSource`` for updates. We write atomically every few
seconds whenever we're running, plus on shutdown so the final ``state``
reflects that the daemon stopped intentionally.

Schema (v1):

    {
      "schema_version": 1,
      "state": "idle" | "syncing" | "paused" | "error" | "stopped",
      "sync_dir": "/Users/.../rm-sync-writing",
      "remote_folder": "Writing",
      "tracked_docs": 42,
      "conflicts": 0,
      "errors": 0,
      "queue_depth": 0,
      "last_pull_at": "2026-04-18T00:52:01Z" | null,
      "last_push_at": "2026-04-18T00:26:21Z" | null,
      "last_error": "..." | null,
      "updated_at": "2026-04-18T00:54:22Z",
      "pid": 12345
    }
"""

from __future__ import annotations

import asyncio
import json
import os
from datetime import datetime, timezone
from pathlib import Path

from rm_sync.config import STATUS_JSON_PATH, Config
from rm_sync.logging_setup import get
from rm_sync.paths import atomic_write_text
from rm_sync.state import State

log = get(__name__)

SCHEMA_VERSION = 1


class StatusWriter:
    """Background task that snapshots daemon state to ``STATUS_JSON_PATH``.

    One tick:
      1. Query the state DB for document counts.
      2. Build a JSON blob.
      3. atomic_write_text it.

    Called on a short interval (default 5s). Also exposes ``mark_error``
    and ``mark_shutdown`` for transition events outside the tick loop.
    """

    def __init__(
        self,
        state: State,
        cfg: Config,
        queue: asyncio.Queue | None = None,
        *,
        interval_seconds: float = 60.0,
        bus=None,
    ):
        self.state = state
        self.cfg = cfg
        self.queue = queue
        self.bus = bus
        self.interval = interval_seconds
        self._stop = asyncio.Event()
        self._last_error: str | None = None

    def mark_error(self, message: str) -> None:
        self._last_error = message

    async def run(self) -> None:
        log.debug("status writer started", path=str(STATUS_JSON_PATH))
        try:
            while not self._stop.is_set():
                await self._tick("syncing" if self._has_activity() else "idle")
                try:
                    await asyncio.wait_for(self._stop.wait(), timeout=self.interval)
                except asyncio.TimeoutError:
                    pass
        finally:
            # Best-effort final write so the menu bar knows we're gone.
            await self._tick("stopped")

    def stop(self) -> None:
        self._stop.set()

    def _has_activity(self) -> bool:
        return bool(self.queue and not self.queue.empty())

    async def _tick(self, fallback_state: str) -> None:
        try:
            paused = await self.state.is_paused()
            if paused:
                state = "paused"
            elif self._last_error and fallback_state != "stopped":
                state = "error"
            else:
                state = fallback_state

            docs = await self.state.all_documents()
            tracked = sum(1 for d in docs if d.doc_type == "DocumentType")
            conflicts = sum(
                1 for d in docs if d.conflict_state == "unresolved"
            )
            errors = sum(1 for d in docs if d.error_state is not None)
            last_pull = max(
                (d.last_pull_at for d in docs if d.last_pull_at), default=None
            )
            last_push = max(
                (d.last_push_at for d in docs if d.last_push_at), default=None
            )

            # Bus is the fast channel; file is a debug fallback.
            if self.bus is not None:
                await self.bus.update(
                    state=state,
                    sync_dir=str(self.cfg.sync_dir),
                    remote_folder=self.cfg.remote_folder,
                    tracked_docs=tracked,
                    conflicts=conflicts,
                    errors=errors,
                    queue_depth=self.queue.qsize() if self.queue else 0,
                    last_pull_at=last_pull,
                    last_push_at=last_push,
                    last_error=self._last_error if state == "error" else None,
                    paused=paused,
                    pid=os.getpid(),
                )

            payload = {
                "schema_version": SCHEMA_VERSION,
                "state": state,
                "sync_dir": str(self.cfg.sync_dir),
                "remote_folder": self.cfg.remote_folder,
                "tracked_docs": tracked,
                "conflicts": conflicts,
                "errors": errors,
                "queue_depth": self.queue.qsize() if self.queue else 0,
                "last_pull_at": last_pull,
                "last_push_at": last_push,
                "last_error": self._last_error if state == "error" else None,
                "paused": paused,
                "updated_at": datetime.now(timezone.utc).isoformat(),
                "pid": os.getpid(),
            }
            atomic_write_text(STATUS_JSON_PATH, json.dumps(payload, indent=2) + "\n")
        except Exception:
            # Don't let status writing take down the daemon.
            log.debug("status write failed", exc_info=True)


def read_status() -> dict | None:
    """Read the current status blob. Used by CLI subcommands and tests."""
    if not STATUS_JSON_PATH.exists():
        return None
    try:
        return json.loads(STATUS_JSON_PATH.read_text())
    except (OSError, json.JSONDecodeError):
        return None
