"""CloudPoller — adaptive polling loop.

Lists the remote Writing tree on an interval that adapts to recent activity.

For each remote node whose ``ModifiedClient`` is newer than what's stored,
enqueues a PULL job. ``Version`` is not used as a change signal because
under sync15 it is pinned to 0 (verified against a real account; see
scripts/cloud_probe2.py and CHANGES_FROM_SPEC.md).

Tombstones (rows in state with no matching remote node) become DELETE_LOCAL
jobs after one safety cycle.
"""

from __future__ import annotations

import asyncio
import time
from pathlib import Path

from rm_sync.cloud import Cloud, Node, RmapiError, RmapiThrottled
from rm_sync.config import Config
from rm_sync.jobs import Job, JobKind
from rm_sync.logging_setup import get
from rm_sync.paths import remote_to_local
from rm_sync.state import State

log = get(__name__)

ACTIVE_WINDOW_S = 5 * 60
IDLE_WINDOW_S = 20 * 60


class CloudPoller:
    def __init__(
        self,
        cloud: Cloud,
        state: State,
        cfg: Config,
        queue: asyncio.Queue[Job],
        sync_dir: Path,
    ):
        self.cloud = cloud
        self.state = state
        self.cfg = cfg
        self.queue = queue
        self.sync_dir = sync_dir
        self._last_change_at: float = 0.0
        self._stop = asyncio.Event()
        # Set by IPC's sync_now handler to break out of the sleep loop.
        self._force_cycle = asyncio.Event()
        # Pending tombstones: doc_id → first-seen-missing time
        self._pending_deletes: dict[str, float] = {}

    def request_cycle(self) -> None:
        """Ask the poller to run its next cycle immediately."""
        self._force_cycle.set()

    def stop(self) -> None:
        self._stop.set()

    async def run(self) -> None:
        log.info("poller started")
        while not self._stop.is_set():
            try:
                await self._cycle()
            except RmapiThrottled as e:
                log.warning("rmapi throttled", error=str(e))
                await asyncio.sleep(60)
            except RmapiError as e:
                log.error("rmapi failure", error=str(e))
                await asyncio.sleep(self.cfg.poll_interval_seconds)
            except Exception:
                log.exception("poller cycle crashed")
                await asyncio.sleep(self.cfg.poll_interval_seconds)
            else:
                await self._sleep_until_next_cycle()
        log.info("poller stopped")

    async def _sleep_until_next_cycle(self) -> None:
        now = time.monotonic()
        since = now - self._last_change_at if self._last_change_at else float("inf")
        if since < ACTIVE_WINDOW_S:
            interval = self.cfg.poll_active_interval_seconds
        elif since > IDLE_WINDOW_S:
            interval = self.cfg.poll_idle_interval_seconds
        else:
            interval = self.cfg.poll_interval_seconds
        # Either the stop signal, the force-cycle event, or the normal
        # timeout ends the sleep. Whichever fires first wins.
        stop_task = asyncio.create_task(self._stop.wait())
        force_task = asyncio.create_task(self._force_cycle.wait())
        try:
            done, _ = await asyncio.wait(
                {stop_task, force_task},
                timeout=interval,
                return_when=asyncio.FIRST_COMPLETED,
            )
            if force_task in done:
                self._force_cycle.clear()
                log.info("force-sync requested")
        finally:
            stop_task.cancel()
            force_task.cancel()

    async def _cycle(self) -> None:
        nodes = await self.cloud.tree(f"/{self.cfg.remote_folder}")

        seen_ids: set[str] = set()
        any_change = False

        for node in nodes:
            if node.type != "DocumentType":
                continue
            seen_ids.add(node.id)
            stored = await self.state.get(node.id)
            remote_path = node.remote_path
            local_path = str(
                remote_to_local(remote_path, self.sync_dir, self.cfg.remote_folder)
            )

            if stored is None:
                any_change = True
                log.info("new remote doc", doc_id=node.id, path=remote_path)
                await self.queue.put(
                    Job(kind=JobKind.PULL, doc_id=node.id, hint=remote_path)
                )
                continue

            # ModifiedClient is the authoritative change signal. Empty
            # stored value means this is the first time we're seeing it.
            if node.modified_client and node.modified_client != (stored.remote_modified or ""):
                any_change = True
                log.info(
                    "remote changed",
                    doc_id=node.id,
                    old_modified=stored.remote_modified,
                    new_modified=node.modified_client,
                )
                await self.queue.put(
                    Job(kind=JobKind.PULL, doc_id=node.id, hint=remote_path)
                )

            # Detect rename/move (path changed).
            if remote_path != stored.remote_path or local_path != stored.local_path:
                any_change = True
                log.info("remote renamed/moved", doc_id=node.id, new_path=remote_path)
                await self.queue.put(
                    Job(kind=JobKind.RENAME_REMOTE, doc_id=node.id, hint=remote_path)
                )

        await self._handle_missing(seen_ids)

        if any_change:
            self._last_change_at = time.monotonic()

    async def _handle_missing(self, seen_ids: set[str]) -> None:
        now = time.monotonic()
        for doc in await self.state.all_documents():
            if doc.doc_type != "DocumentType":
                continue
            if doc.doc_id in seen_ids:
                self._pending_deletes.pop(doc.doc_id, None)
                continue
            first_seen = self._pending_deletes.setdefault(doc.doc_id, now)
            if now - first_seen >= self.cfg.poll_interval_seconds:
                log.info("remote deletion confirmed", doc_id=doc.doc_id)
                await self.queue.put(
                    Job(kind=JobKind.DELETE_LOCAL, doc_id=doc.doc_id, hint=doc.local_path)
                )
                self._pending_deletes.pop(doc.doc_id, None)


