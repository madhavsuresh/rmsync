"""``rmapi`` subprocess wrapper.

Rewritten after the real-cloud probe (see scripts/cloud_probe.py,
scripts/cloud_probe2.py) surfaced these corrections to the original spec:

  - There is no ``--json`` flag on ``find`` or ``ls``. Both emit plain text
    with ``[d]\\t<name>`` / ``[f]\\t<name>`` lines. Only ``stat`` returns
    JSON (on stdout inside the interactive shell).
  - ``--content-only`` is PDF-only. For .rmdoc updates use ``--force``.
  - Under sync15 the ``Version`` field is pinned to 0. ``ModifiedClient``
    (RFC3339, second precision) is the only usable change-detection signal.

We drive the tree walk with ``find`` (recursive) and then issue ``stat``
per document to get metadata. The extra round-trip is unavoidable; rmapi
does not expose bulk metadata.
"""

from __future__ import annotations

import asyncio
import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

from rm_sync.logging_setup import get

log = get(__name__)

# Tested compatibility range. Re-test when bumping.
RMAPI_MIN = (0, 0, 30)
RMAPI_MAX_EXCLUSIVE = (0, 1, 0)


@dataclass
class Node:
    """One reMarkable tree entry. ``modified_client`` is the authoritative
    change signal under sync15; ``version`` is kept for completeness but is
    always 0 on accounts we've tested."""

    id: str
    name: str
    type: Literal["CollectionType", "DocumentType"]
    parent: str
    modified_client: str  # RFC3339, e.g. "2026-04-17T19:03:46Z"
    version: int = 0
    current_page: int = 0
    # Absolute remote path as a list of segments (root excluded).
    path: tuple[str, ...] = field(default_factory=tuple)

    @property
    def remote_path(self) -> str:
        return "/" + "/".join(self.path)


class RmapiError(RuntimeError):
    def __init__(self, returncode: int, stdout: str, stderr: str, argv: list[str]):
        self.returncode = returncode
        self.stdout = stdout
        self.stderr = stderr
        self.argv = argv
        super().__init__(
            f"rmapi {' '.join(argv)} exited {returncode}\nstderr: {stderr.strip()}"
        )


class RmapiThrottled(RmapiError):
    """rmapi reported a 429/503 — back off."""


_THROTTLE_PATTERNS = (
    re.compile(r"\b429\b"),
    re.compile(r"\b503\b"),
    re.compile(r"too many requests", re.IGNORECASE),
    re.compile(r"rate.{0,5}limit", re.IGNORECASE),
)
_LS_LINE = re.compile(r"^\[(?P<k>[df])\]\s*(?P<name>.+)$")


class Cloud:
    def __init__(self, *, rmapi: str = "rmapi", concurrent_override: int | None = None):
        self.rmapi = rmapi
        self.concurrent_override = concurrent_override

    # ---- meta ---------------------------------------------------------------

    async def version(self) -> tuple[int, int, int]:
        out = await self._run("version")
        m = re.search(r"(\d+)\.(\d+)\.(\d+)", out)
        if not m:
            raise RmapiError(0, out, "", [self.rmapi, "version"])
        return (int(m.group(1)), int(m.group(2)), int(m.group(3)))

    async def check_version(self) -> None:
        v = await self.version()
        if not (RMAPI_MIN <= v < RMAPI_MAX_EXCLUSIVE):
            log.warning(
                "rmapi version outside tested range",
                found=".".join(map(str, v)),
                min=".".join(map(str, RMAPI_MIN)),
                max_exclusive=".".join(map(str, RMAPI_MAX_EXCLUSIVE)),
            )

    # ---- listing ------------------------------------------------------------

    async def ls(self, remote_path: str) -> list[tuple[str, str]]:
        """Return [(kind, name), ...] for direct children of ``remote_path``.

        kind is 'd' (collection) or 'f' (document).
        """
        out = await self._shell(f"ls {_escape(remote_path)}\n")
        return _parse_listing(out)

    async def find(self, remote_path: str) -> list[str]:
        """Recursive listing. Returns relative-to-root paths with d/f prefix.

        Example line: ``[f] Writing/Notes/2025-01``. The rmapi ``find``
        command recursively walks with one entry per line.
        """
        out = await self._shell(f"find {_escape(remote_path)}\n")
        entries: list[str] = []
        for line in out.splitlines():
            if line.startswith("[d]") or line.startswith("[f]"):
                entries.append(line.strip())
        return entries

    async def stat(self, remote_path: str) -> dict | None:
        """Return the JSON metadata blob for ``remote_path``, or None on error."""
        out = await self._shell(f"stat {_escape(remote_path)}\n")
        brace, end = out.find("{"), out.rfind("}")
        if brace < 0 or end < 0:
            return None
        try:
            return json.loads(out[brace : end + 1])
        except json.JSONDecodeError:
            return None

    async def tree(self, root: str) -> list[Node]:
        """Walk the subtree at ``root`` and return a Node per entry
        (excluding the root itself).

        Uses ``find`` to enumerate, then ``stat`` per entry for metadata.
        ``find`` prints paths prefixed with the ROOT'S LAST SEGMENT, not
        the full absolute path. Example: ``find /Archive/Fd`` prints
        ``Fd/Draft``, not ``Archive/Fd/Draft``. We prepend the parent of
        ``root`` to reconstruct absolute remote paths.

        Expensive on large trees (one stat per doc) but unavoidable with
        rmapi's current CLI surface — no bulk-metadata endpoint is exposed.
        """
        entries = await self.find(root)
        root_segs = tuple(s for s in root.strip("/").split("/") if s)
        parent_segs = root_segs[:-1]  # everything before the last segment

        nodes: list[Node] = []
        for line in entries:
            kind = "d" if line.startswith("[d]") else "f"
            printed = line[3:].lstrip("\t ").strip()
            rel_segs = tuple(s for s in printed.split("/") if s)
            if not rel_segs:
                continue
            # The root itself shows up as a single segment equal to the
            # last segment of root. Skip it.
            if rel_segs == root_segs[-1:]:
                continue

            path_segs = parent_segs + rel_segs
            remote = "/" + "/".join(path_segs)
            meta = await self.stat(remote)
            if meta is None:
                log.warning("stat failed for tree entry", path=remote)
                continue

            nodes.append(
                Node(
                    id=meta.get("ID", ""),
                    name=meta.get("Name", rel_segs[-1]),
                    type=(
                        "CollectionType"
                        if kind == "d" or meta.get("Type") == "CollectionType"
                        else "DocumentType"
                    ),
                    parent=meta.get("Parent", ""),
                    modified_client=meta.get("ModifiedClient", ""),
                    version=int(meta.get("Version", 0)),
                    current_page=int(meta.get("CurrentPage", 0)),
                    path=path_segs,
                )
            )
        return nodes

    # ---- transfer -----------------------------------------------------------

    async def get(self, remote_path: str, dest: Path) -> Path:
        """Download a single document into ``dest`` directory. Returns the .rmdoc path."""
        dest.mkdir(parents=True, exist_ok=True)
        await self._run("get", remote_path, cwd=dest)
        archives = sorted(dest.glob("*.rmdoc"), key=lambda p: p.stat().st_mtime, reverse=True)
        if not archives:
            raise RmapiError(0, "", "no .rmdoc produced", [self.rmapi, "get", remote_path])
        return archives[0]

    async def mget(self, remote_path: str, dest_dir: Path, *, incremental: bool = True) -> None:
        """Recursive incremental pull. Never use ``-d`` — it deletes local work."""
        dest_dir.mkdir(parents=True, exist_ok=True)
        args = ["mget"]
        if incremental:
            args.append("-i")
        args += ["-o", str(dest_dir), remote_path]
        await self._run(*args)

    async def put(self, local: Path, remote_parent: str, *, update: bool = False) -> None:
        """Upload ``local`` (a .rmdoc) into ``remote_parent``.

        With ``update=True``, adds ``--force`` so an existing document with
        the same name is replaced in place (same UUID preserved across
        updates — verified against real cloud in scripts/cloud_probe2.py).

        Without ``update``, rmapi refuses when a doc with that name already
        exists (rc=1, 'entry already exists').
        """
        args = ["put"]
        if update:
            args.append("--force")
        args += [str(local), remote_parent]
        await self._run(*args)

    async def mkdir(self, remote_path: str) -> None:
        await self._run("mkdir", remote_path)

    async def mv(self, src: str, dst: str) -> None:
        await self._run("mv", src, dst)

    async def rm(self, remote_path: str) -> None:
        """Move to cloud trash. Not a hard delete."""
        await self._run("rm", remote_path)

    # ---- internals ----------------------------------------------------------

    async def _run(self, *args: str, cwd: Path | None = None) -> str:
        argv = [self.rmapi, *args]
        env = os.environ.copy()
        if self.concurrent_override is not None:
            env["RMAPI_CONCURRENT"] = str(self.concurrent_override)
        proc = await asyncio.create_subprocess_exec(
            *argv,
            cwd=str(cwd) if cwd else None,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env,
        )
        stdout_b, stderr_b = await proc.communicate()
        stdout = stdout_b.decode("utf-8", errors="replace")
        stderr = stderr_b.decode("utf-8", errors="replace")
        if proc.returncode != 0:
            haystack = f"{stdout}\n{stderr}"
            if any(p.search(haystack) for p in _THROTTLE_PATTERNS):
                raise RmapiThrottled(proc.returncode or 1, stdout, stderr, argv)
            raise RmapiError(proc.returncode or 1, stdout, stderr, argv)
        return stdout

    async def _shell(self, commands: str) -> str:
        """Drive rmapi's interactive shell via stdin, for commands that only
        exist there (find/ls/stat). Returns the combined stdout."""
        argv = [self.rmapi]
        env = os.environ.copy()
        if self.concurrent_override is not None:
            env["RMAPI_CONCURRENT"] = str(self.concurrent_override)
        proc = await asyncio.create_subprocess_exec(
            *argv,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env,
        )
        stdout_b, stderr_b = await proc.communicate(commands.encode("utf-8"))
        stdout = stdout_b.decode("utf-8", errors="replace")
        stderr = stderr_b.decode("utf-8", errors="replace")
        # Shell mode returns rc=0 even when individual commands failed; we
        # rely on output parsing to detect missing entries. Throttle signals
        # surface as strings in stdout, so check both.
        haystack = f"{stdout}\n{stderr}"
        if any(p.search(haystack) for p in _THROTTLE_PATTERNS):
            raise RmapiThrottled(1, stdout, stderr, argv)
        return stdout


def _escape(path: str) -> str:
    """Quote a remote path for the rmapi shell (spaces are common)."""
    if " " in path:
        return f'"{path}"'
    return path


def _parse_listing(shell_output: str) -> list[tuple[str, str]]:
    items: list[tuple[str, str]] = []
    for line in shell_output.splitlines():
        m = _LS_LINE.match(line.strip())
        if m:
            items.append((m.group("k"), m.group("name").lstrip("\t ")))
    return items
