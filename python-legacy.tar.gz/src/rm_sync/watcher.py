"""Local filesystem watcher.

watchdog runs in its own thread; we bridge events into the asyncio queue
via :py:meth:`asyncio.AbstractEventLoop.call_soon_threadsafe`.

Per-path debouncing collapses bursts of editor save events into one push.
The echo fence drops events caused by our own writes (defense #1).

Important: the watcher is started AFTER the initial reconciliation pull
completes (see daemon.py). Otherwise, the initial pull's N file creates
would each fire spurious push events. The hash check in the worker is the
load-bearing defense, but starting the watcher last avoids the noise.
"""

from __future__ import annotations

import asyncio
import re
import threading
from pathlib import Path

from watchdog.events import (
    FileSystemEvent,
    FileSystemEventHandler,
)
from watchdog.observers import Observer

from rm_sync.echo_fence import EchoFence
from rm_sync.jobs import Job, JobKind
from rm_sync.logging_setup import get
from rm_sync.paths import normalize_for_compare

log = get(__name__)

_IGNORE_BASENAMES = {".DS_Store"}
# Dropbox / iCloud / OneDrive all produce filenames of the form
# ``<stem> (<actor>'s conflicted copy <date>).md``. Never push these.
_CONFLICT_COPY_RE = re.compile(r"\bconflicted copy\b", re.IGNORECASE)


def _should_ignore(path: str, sync_dir: Path) -> bool:
    p = Path(path)
    if p.name in _IGNORE_BASENAMES:
        return True
    if p.name.startswith("."):
        return True
    if p.suffix == ".tmp":
        return True
    if p.suffix == ".conflict":
        return True
    if _CONFLICT_COPY_RE.search(p.name):
        return True
    rel = p.relative_to(sync_dir) if sync_dir in p.parents or p == sync_dir else None
    if rel is not None:
        for part in rel.parts:
            if part in {".rm-sync-trash", ".git", ".obsidian"}:
                return True
            if part.startswith("."):
                return True
    if p.suffix not in {".md"}:
        return True
    return False


class _Handler(FileSystemEventHandler):
    def __init__(
        self,
        sync_dir: Path,
        loop: asyncio.AbstractEventLoop,
        queue: asyncio.Queue[Job],
        fence: EchoFence,
        debounce_seconds: float,
    ):
        super().__init__()
        self.sync_dir = sync_dir
        self.loop = loop
        self.queue = queue
        self.fence = fence
        self.debounce_seconds = debounce_seconds
        # Per-path debounce timers (threading.Timer).
        self._timers: dict[str, threading.Timer] = {}
        self._timer_lock = threading.Lock()

    # ---- watchdog callbacks ------------------------------------------------

    def on_created(self, event: FileSystemEvent) -> None:
        log.debug("fs event", op="create", path=event.src_path, is_dir=event.is_directory)
        if event.is_directory:
            return
        self._maybe_enqueue_push(event.src_path)

    def on_modified(self, event: FileSystemEvent) -> None:
        log.debug("fs event", op="modify", path=event.src_path, is_dir=event.is_directory)
        if event.is_directory:
            return
        self._maybe_enqueue_push(event.src_path)

    def on_moved(self, event: FileSystemEvent) -> None:
        log.debug(
            "fs event",
            op="move",
            src=event.src_path,
            dest=event.dest_path,
            is_dir=event.is_directory,
        )
        if event.is_directory:
            return
        self._maybe_enqueue_push(event.dest_path)

    def on_deleted(self, event: FileSystemEvent) -> None:
        log.debug("fs event", op="delete", path=event.src_path, is_dir=event.is_directory)
        if event.is_directory:
            return
        if _should_ignore(event.src_path, self.sync_dir):
            return
        self._submit(Job(kind=JobKind.DELETE_LOCAL, doc_id=None, hint=event.src_path))

    # ---- helpers -----------------------------------------------------------

    def _maybe_enqueue_push(self, path: str) -> None:
        norm = normalize_for_compare(path)
        if _should_ignore(norm, self.sync_dir):
            return
        if self.fence.is_recent(norm):
            log.debug("echo-suppressed", path=norm)
            return
        self._debounce(norm)

    def _debounce(self, path: str) -> None:
        with self._timer_lock:
            existing = self._timers.pop(path, None)
            if existing is not None:
                existing.cancel()
            t = threading.Timer(self.debounce_seconds, self._fire, args=(path,))
            t.daemon = True
            self._timers[path] = t
            t.start()

    def _fire(self, path: str) -> None:
        with self._timer_lock:
            self._timers.pop(path, None)
        self._submit(Job(kind=JobKind.PUSH, doc_id=None, hint=path))

    def _submit(self, job: Job) -> None:
        self.loop.call_soon_threadsafe(self.queue.put_nowait, job)


class LocalWatcher:
    def __init__(
        self,
        sync_dir: Path,
        queue: asyncio.Queue[Job],
        fence: EchoFence,
        debounce_seconds: float,
    ):
        self.sync_dir = sync_dir
        self.queue = queue
        self.fence = fence
        self.debounce_seconds = debounce_seconds
        self._observer: Observer | None = None

    def start(self) -> None:
        loop = asyncio.get_running_loop()
        handler = _Handler(self.sync_dir, loop, self.queue, self.fence, self.debounce_seconds)
        self._observer = Observer()
        self._observer.schedule(handler, str(self.sync_dir), recursive=True)
        self._observer.start()
        log.info("watcher started", sync_dir=str(self.sync_dir))

    def stop(self) -> None:
        if self._observer is not None:
            self._observer.stop()
            self._observer.join(timeout=5)
            self._observer = None
            log.info("watcher stopped")
