"""Configuration loader.

Single source of truth for tunables. Reads ``~/.config/rm-sync/config.toml``.
All filesystem paths used elsewhere in the daemon are derived from constants
defined here so tests can monkey-patch them.
"""

from __future__ import annotations

import os
import tomllib
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field, field_validator

# Well-known on-disk locations. Override via env vars for tests.
CONFIG_PATH = Path(
    os.environ.get("RM_SYNC_CONFIG", str(Path.home() / ".config/rm-sync/config.toml"))
)
STATE_DIR = Path(
    os.environ.get(
        "RM_SYNC_STATE_DIR", str(Path.home() / "Library/Application Support/rm-sync")
    )
)
LOG_DIR = Path(
    os.environ.get("RM_SYNC_LOG_DIR", str(Path.home() / "Library/Logs/rm-sync"))
)
STATE_DB_PATH = STATE_DIR / "state.db"
# Legacy: migrated into state.db's settings.paused in schema v4. Kept as a
# constant so the migration code can still locate it during upgrade.
PAUSE_SENTINEL = STATE_DIR / "paused"
RESYNC_DIR = STATE_DIR / "resync"
BACKUP_DIR = STATE_DIR / "backups"
# Written periodically by the daemon; read by the Swift menu bar app as a
# fallback when the IPC socket is unavailable.
STATUS_JSON_PATH = STATE_DIR / "status.json"
# Unix domain socket for the live IPC channel between daemon and UI/CLI.
IPC_SOCKET_PATH = STATE_DIR / "ipc.sock"


class LogConfig(BaseModel):
    level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"


class Config(BaseModel):
    sync_dir: Path
    remote_folder: str = "Writing"

    worker_pool_size: int = Field(3, ge=1, le=6)
    poll_interval_seconds: int = Field(30, ge=10)
    poll_active_interval_seconds: int = Field(15, ge=10)
    poll_idle_interval_seconds: int = Field(120, ge=60)
    debounce_seconds: float = Field(2.0, ge=0.5)
    rename_detect_window_s: float = Field(5.0, ge=1.0)
    echo_fence_seconds: float = Field(5.0, ge=2.0)
    retry_max_attempts: int = Field(3, ge=1, le=5)

    push_strategy: Literal["native_plain", "native_formatted", "pdf"] = "native_plain"

    backup_snapshots_to_keep: int = Field(30, ge=5)
    dry_run: bool = False

    log: LogConfig = Field(default_factory=LogConfig)

    @field_validator("sync_dir", mode="before")
    @classmethod
    def _expand_home(cls, v: str | Path) -> Path:
        return Path(v).expanduser()


def load(path: Path | None = None) -> Config:
    """Read TOML from ``path`` (or the default) and return a validated Config."""
    cfg_path = path or CONFIG_PATH
    if not cfg_path.exists():
        raise FileNotFoundError(
            f"No config at {cfg_path}. Run install.sh or `rm-sync init` first."
        )
    with cfg_path.open("rb") as f:
        raw = tomllib.load(f)
    return Config(**raw)
