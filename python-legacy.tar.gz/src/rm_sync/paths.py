"""Path mapping and sanitization helpers.

Two principal jobs:
  1. Convert reMarkable display names into safe macOS path segments.
  2. Atomic file writes (so the watcher / user's editor never observes a
     half-written .md).
"""

from __future__ import annotations

import os
import re
import unicodedata
import uuid
from pathlib import Path

_ILLEGAL = re.compile(r'[\x00-\x1f/\\:?*<>"|]')
_WINDOWS_RESERVED = (
    {"CON", "PRN", "AUX", "NUL"}
    | {f"COM{i}" for i in range(1, 10)}
    | {f"LPT{i}" for i in range(1, 10)}
)


def remote_to_local(remote_path: str, sync_dir: Path, remote_folder: str) -> Path:
    """Map a remote path like ``/Writing/sub/doc`` to a local .md path.

    The sync_dir already implies the remote_folder, so we strip it. Each
    remaining segment is sanitized. Single source of truth — both the
    poller and worker must use this to avoid drift that would fire
    spurious RENAME_REMOTE jobs on every poll cycle.
    """
    parts = [p for p in remote_path.split("/") if p]
    if parts and parts[0] == remote_folder:
        parts = parts[1:]
    safe = [sanitize_segment(p) for p in parts]
    if not safe:
        return sync_dir / "untitled.md"
    return sync_dir.joinpath(*safe[:-1]) / (safe[-1] + ".md")


def sanitize_segment(name: str) -> str:
    """Make ``name`` safe for a single macOS path segment.

    NFC-normalize, replace forbidden characters with underscore, collapse
    runs of underscores, strip leading/trailing dots and spaces, fall back
    to ``untitled`` if the result is empty, escape Windows-reserved names,
    truncate to 200 chars.
    """
    s = unicodedata.normalize("NFC", name)
    s = _ILLEGAL.sub("_", s)
    s = re.sub(r"_+", "_", s)
    s = s.strip(" .")
    if not s:
        s = "untitled"
    if s.upper() in _WINDOWS_RESERVED:
        s = f"_{s}_"
    return s[:200]


def disambiguate(base: str, taken: set[str]) -> str:
    """If ``base`` collides with a name in ``taken``, append a short uuid."""
    if base not in taken:
        return base
    suffix = uuid.uuid4().hex[:6]
    if "." in base:
        stem, ext = base.rsplit(".", 1)
        return f"{stem}_{suffix}.{ext}"
    return f"{base}_{suffix}"


def normalize_for_compare(p: str | Path) -> str:
    """Normalize unicode form so APFS (NFD) and source (NFC) paths compare equal."""
    return unicodedata.normalize("NFC", str(p))


def atomic_write_text(
    path: Path,
    text: str,
    *,
    encoding: str = "utf-8",
    metadata: "object | None" = None,
) -> None:
    """Write ``text`` to ``path`` atomically: write tmp, fsync, os.replace.

    Prevents the watcher and the user's editor from seeing a partial file.

    If ``metadata`` is a :class:`rm_sync.native.macos.FileMetadata`, its
    xattrs are applied after the replace. Passing non-None on a non-macOS
    host is a no-op (the helper handles platform detection).
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding=encoding, newline="\n") as f:
        f.write(text)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)
    if metadata is not None:
        # Import lazily so the core write path stays portable.
        from rm_sync.native import macos as _native

        _native.apply_metadata(path, metadata)  # type: ignore[arg-type]


def case_only_rename(src: Path, dst: Path) -> None:
    """Rename ``src`` to ``dst`` even if they differ only by case on APFS.

    Default APFS volumes are case-insensitive but case-preserving, so a
    direct rename is silently a no-op. Two-step through an intermediate name.
    """
    if src == dst:
        return
    if src.name.lower() == dst.name.lower() and src.parent == dst.parent:
        intermediate = src.with_name(src.name + ".__case_fix__")
        os.rename(src, intermediate)
        os.rename(intermediate, dst)
    else:
        os.rename(src, dst)
