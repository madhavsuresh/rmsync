"""Conflict marker file management.

When both sides of a doc have changed since the last sync, the daemon
writes ``<file>.md.conflict`` next to the live ``<file>.md`` with git-style
markers and refuses to touch the live file until the conflict is resolved.

Resolution protocol:
  1. User edits the live .md to the desired final state.
  2. User deletes the .md.conflict file.
  3. Daemon detects (conflict_state='unresolved' AND no .conflict file
     present) → treats live .md as authoritative → pushes → clears state.
"""

from __future__ import annotations

from pathlib import Path

from rm_sync.paths import atomic_write_text


def conflict_path_for(md_path: Path) -> Path:
    return md_path.with_suffix(md_path.suffix + ".conflict")


def write_conflict(md_path: Path, *, local: str, remote: str, base: str | None = None) -> Path:
    """Write a .conflict file with git-style markers. Live file is untouched."""
    base = base if base is not None else "(no common ancestor recorded)"
    body = (
        "<<<<<<< local\n"
        f"{local}"
        f"{'' if local.endswith(chr(10)) else chr(10)}"
        "||||||| base\n"
        f"{base}"
        f"{'' if base.endswith(chr(10)) else chr(10)}"
        "=======\n"
        f"{remote}"
        f"{'' if remote.endswith(chr(10)) else chr(10)}"
        ">>>>>>> remote\n"
    )
    cp = conflict_path_for(md_path)
    atomic_write_text(cp, body)
    return cp


def has_unresolved_conflict_file(md_path: Path) -> bool:
    return conflict_path_for(md_path).exists()
