"""Per-doc-id asyncio lock registry.

Workers may process different documents concurrently, but the same document
must never have two operations in flight. Get a lock with::

    async with locks.acquire(doc_id):
        ...
"""

from __future__ import annotations

import asyncio
from collections import defaultdict
from contextlib import asynccontextmanager
from typing import AsyncIterator


class LockRegistry:
    def __init__(self) -> None:
        self._locks: dict[str, asyncio.Lock] = defaultdict(asyncio.Lock)

    @asynccontextmanager
    async def acquire(self, key: str) -> AsyncIterator[None]:
        lock = self._locks[key]
        await lock.acquire()
        try:
            yield
        finally:
            lock.release()
