"""SQLite state DB.

Schema deviates from the original spec by collapsing the two hash columns
into a single ``last_synced_md_hash`` (see CHANGES_FROM_SPEC.md). Also adds
``error_state`` so a single bad document parks itself instead of crashing
the worker loop.

Under sync15, ``Version`` is pinned to 0 cloud-side — confirmed against a
real account. The authoritative change signal is ``ModifiedClient``
(RFC3339 timestamp, second precision). We keep ``remote_version`` in the
schema because the DocumentType's original protocol used it, but all
change-detection logic reads ``remote_modified``.
"""

from __future__ import annotations

import json
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import AsyncIterator

import aiosqlite

SCHEMA_VERSION = 4

SCHEMA = """
CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER PRIMARY KEY
);

CREATE TABLE IF NOT EXISTS settings (
    key     TEXT PRIMARY KEY,
    value   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS documents (
    doc_id              TEXT PRIMARY KEY,
    parent_id           TEXT NOT NULL,
    doc_type            TEXT NOT NULL,
    title               TEXT NOT NULL,
    remote_path         TEXT NOT NULL,
    local_path          TEXT NOT NULL,
    remote_version      INTEGER NOT NULL,
    remote_modified     TEXT,
    last_synced_md_hash TEXT,
    last_pull_at        TEXT,
    last_push_at        TEXT,
    conflict_state      TEXT,                  -- NULL | 'unresolved'
    error_state         TEXT,                  -- NULL | 'parse_failed' | 'push_validation_failed'
    page_ids            TEXT                   -- JSON list of page UUIDs (sync15 cPages.pages[].id)
);
CREATE INDEX IF NOT EXISTS idx_parent       ON documents(parent_id);
CREATE INDEX IF NOT EXISTS idx_local_path   ON documents(local_path);
CREATE INDEX IF NOT EXISTS idx_remote_path  ON documents(remote_path);

CREATE TABLE IF NOT EXISTS sync_log (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    ts      TEXT NOT NULL,
    level   TEXT NOT NULL,
    doc_id  TEXT,
    message TEXT NOT NULL
);
"""


@dataclass
class Document:
    doc_id: str
    parent_id: str
    doc_type: str  # 'DocumentType' | 'CollectionType'
    title: str
    remote_path: str
    local_path: str
    remote_version: int
    remote_modified: str | None = None
    last_synced_md_hash: str | None = None
    last_pull_at: str | None = None
    last_push_at: str | None = None
    conflict_state: str | None = None
    error_state: str | None = None
    # sync15 page UUIDs, in order. Must be reused across updates of the
    # same doc — generating new UUIDs each push causes the cloud's
    # cPages CRDT to accumulate ghost entries, which the tablet renders
    # as trailing blank pages (no .rm file for the ghost id).
    page_ids: list[str] = field(default_factory=list)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class State:
    """Thin async wrapper around aiosqlite. WAL mode, NORMAL sync."""

    def __init__(self, path: Path):
        self.path = path
        self._db: aiosqlite.Connection | None = None

    async def open(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._db = await aiosqlite.connect(self.path)
        self._db.row_factory = aiosqlite.Row
        await self._db.execute("PRAGMA journal_mode=WAL")
        await self._db.execute("PRAGMA synchronous=NORMAL")
        await self._db.executescript(SCHEMA)
        await self._migrate()
        await self._db.commit()

    async def close(self) -> None:
        if self._db is not None:
            await self._db.close()
            self._db = None

    @property
    def db(self) -> aiosqlite.Connection:
        if self._db is None:
            raise RuntimeError("State.open() not called")
        return self._db

    async def _migrate(self) -> None:
        async with self.db.execute("SELECT version FROM schema_version") as cur:
            row = await cur.fetchone()
        current = row["version"] if row else 0
        if current < 1:
            await self.db.execute("INSERT OR REPLACE INTO schema_version(version) VALUES (?)", (1,))
            current = 1
        if current < 2:
            # v2: add page_ids for stable cPages entries across pushes.
            async with self.db.execute("PRAGMA table_info(documents)") as cur:
                cols = [r["name"] for r in await cur.fetchall()]
            if "page_ids" not in cols:
                await self.db.execute("ALTER TABLE documents ADD COLUMN page_ids TEXT")
            await self.db.execute("UPDATE schema_version SET version=?", (2,))
        if current < 3:
            # v3: add settings table. Also seeds author_uuid so that every
            # push from this install goes on the same CRDT author slot —
            # required for content to REPLACE on the tablet instead of
            # merging character-by-character with the prior version.
            await self.db.executescript(
                """
                CREATE TABLE IF NOT EXISTS settings (
                    key   TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                """
            )
            await self.db.execute("UPDATE schema_version SET version=?", (3,))
        if current < 4:
            # v4: migrate the old file-based pause sentinel into a setting
            # so IPC can toggle it without touching the filesystem.
            from rm_sync.config import PAUSE_SENTINEL

            if PAUSE_SENTINEL.exists():
                await self.db.execute(
                    "INSERT OR REPLACE INTO settings(key, value) VALUES (?, ?)",
                    ("paused", "1"),
                )
                try:
                    PAUSE_SENTINEL.unlink()
                except OSError:
                    pass
            await self.db.execute("UPDATE schema_version SET version=?", (4,))

    # ---- documents ----------------------------------------------------------

    async def get(self, doc_id: str) -> Document | None:
        async with self.db.execute("SELECT * FROM documents WHERE doc_id=?", (doc_id,)) as cur:
            row = await cur.fetchone()
        return _row_to_doc(row) if row else None

    async def by_local_path(self, local_path: str) -> Document | None:
        async with self.db.execute(
            "SELECT * FROM documents WHERE local_path=?", (local_path,)
        ) as cur:
            row = await cur.fetchone()
        return _row_to_doc(row) if row else None

    async def all_documents(self) -> list[Document]:
        async with self.db.execute("SELECT * FROM documents") as cur:
            rows = await cur.fetchall()
        return [_row_to_doc(r) for r in rows]

    async def upsert(self, doc: Document) -> None:
        await self.db.execute(
            """
            INSERT INTO documents (
                doc_id, parent_id, doc_type, title, remote_path, local_path,
                remote_version, remote_modified, last_synced_md_hash,
                last_pull_at, last_push_at, conflict_state, error_state,
                page_ids
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(doc_id) DO UPDATE SET
                parent_id          = excluded.parent_id,
                doc_type           = excluded.doc_type,
                title              = excluded.title,
                remote_path        = excluded.remote_path,
                local_path         = excluded.local_path,
                remote_version     = excluded.remote_version,
                remote_modified    = excluded.remote_modified,
                last_synced_md_hash= excluded.last_synced_md_hash,
                last_pull_at       = excluded.last_pull_at,
                last_push_at       = excluded.last_push_at,
                conflict_state     = excluded.conflict_state,
                error_state        = excluded.error_state,
                page_ids           = excluded.page_ids
            """,
            (
                doc.doc_id, doc.parent_id, doc.doc_type, doc.title,
                doc.remote_path, doc.local_path, doc.remote_version,
                doc.remote_modified, doc.last_synced_md_hash,
                doc.last_pull_at, doc.last_push_at,
                doc.conflict_state, doc.error_state,
                json.dumps(doc.page_ids),
            ),
        )
        await self.db.commit()

    async def set_page_ids(self, doc_id: str, page_ids: list[str]) -> None:
        await self.db.execute(
            "UPDATE documents SET page_ids=? WHERE doc_id=?",
            (json.dumps(page_ids), doc_id),
        )
        await self.db.commit()

    async def delete(self, doc_id: str) -> None:
        await self.db.execute("DELETE FROM documents WHERE doc_id=?", (doc_id,))
        await self.db.commit()

    async def set_conflict(self, doc_id: str, state: str | None) -> None:
        await self.db.execute(
            "UPDATE documents SET conflict_state=? WHERE doc_id=?", (state, doc_id)
        )
        await self.db.commit()

    async def set_error(self, doc_id: str, state: str | None) -> None:
        await self.db.execute(
            "UPDATE documents SET error_state=? WHERE doc_id=?", (state, doc_id)
        )
        await self.db.commit()

    async def mark_pulled(
        self,
        doc_id: str,
        *,
        version: int,
        md_hash: str,
        modified: str | None = None,
    ) -> None:
        await self.db.execute(
            """UPDATE documents
               SET remote_version=?, remote_modified=?, last_synced_md_hash=?,
                   last_pull_at=?, error_state=NULL
               WHERE doc_id=?""",
            (version, modified, md_hash, _now_iso(), doc_id),
        )
        await self.db.commit()

    async def mark_pushed(
        self,
        doc_id: str,
        *,
        version: int,
        md_hash: str,
        modified: str | None = None,
    ) -> None:
        await self.db.execute(
            """UPDATE documents
               SET remote_version=?, remote_modified=?, last_synced_md_hash=?,
                   last_push_at=?, error_state=NULL
               WHERE doc_id=?""",
            (version, modified, md_hash, _now_iso(), doc_id),
        )
        await self.db.commit()

    # ---- log ----------------------------------------------------------------

    async def log(self, level: str, message: str, *, doc_id: str | None = None) -> None:
        await self.db.execute(
            "INSERT INTO sync_log(ts, level, doc_id, message) VALUES (?,?,?,?)",
            (_now_iso(), level, doc_id, message),
        )
        await self.db.commit()

    # ---- settings -----------------------------------------------------------

    async def get_setting(self, key: str) -> str | None:
        async with self.db.execute("SELECT value FROM settings WHERE key=?", (key,)) as cur:
            row = await cur.fetchone()
        return row["value"] if row else None

    async def set_setting(self, key: str, value: str) -> None:
        await self.db.execute(
            "INSERT OR REPLACE INTO settings(key, value) VALUES (?, ?)", (key, value)
        )
        await self.db.commit()

    async def is_paused(self) -> bool:
        val = await self.get_setting("paused")
        return val == "1"

    async def set_paused(self, paused: bool) -> None:
        await self.set_setting("paused", "1" if paused else "0")

    async def get_or_create_author_uuid(self) -> str:
        """Return the stable author UUID for this install; create one if missing.

        This UUID is used as the CRDT ``author_uuid`` in every push. Keeping
        it stable across pushes means the tablet sees successive uploads as
        coming from the same author editing the same item — triggering a
        clean replace rather than a character-level CRDT merge.
        """
        import uuid as _uuid

        existing = await self.get_setting("author_uuid")
        if existing:
            return existing
        new = str(_uuid.uuid4())
        await self.set_setting("author_uuid", new)
        return new


def _row_to_doc(row: aiosqlite.Row) -> Document:
    raw_pids = row["page_ids"] if "page_ids" in row.keys() else None
    try:
        page_ids = json.loads(raw_pids) if raw_pids else []
    except (TypeError, json.JSONDecodeError):
        page_ids = []
    return Document(
        doc_id=row["doc_id"],
        parent_id=row["parent_id"],
        doc_type=row["doc_type"],
        title=row["title"],
        remote_path=row["remote_path"],
        local_path=row["local_path"],
        remote_version=row["remote_version"],
        remote_modified=row["remote_modified"],
        last_synced_md_hash=row["last_synced_md_hash"],
        last_pull_at=row["last_pull_at"],
        last_push_at=row["last_push_at"],
        conflict_state=row["conflict_state"],
        error_state=row["error_state"],
        page_ids=page_ids,
    )


@asynccontextmanager
async def open_state(path: Path) -> AsyncIterator[State]:
    s = State(path)
    await s.open()
    try:
        yield s
    finally:
        await s.close()
