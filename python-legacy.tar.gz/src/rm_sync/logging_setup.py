"""structlog configuration. Daemon logs JSON to stderr (captured by launchd)."""

from __future__ import annotations

import logging
import sys

import structlog


def configure(level: str = "INFO", *, json_output: bool = True) -> None:
    """Set up structlog and stdlib logging together. Idempotent."""
    log_level = getattr(logging, level.upper(), logging.INFO)

    logging.basicConfig(
        format="%(message)s",
        stream=sys.stderr,
        level=log_level,
        force=True,
    )
    # Chatty third-party loggers we don't want at DEBUG level.
    for quiet in ("aiosqlite", "asyncio", "watchdog"):
        logging.getLogger(quiet).setLevel(max(log_level, logging.INFO))
    # rmscene prints block-parse warnings with stack traces for every
    # unrecognized extension byte. The reads succeed; suppress to WARNING.
    for rmscene_noisy in (
        "rmscene",
        "rmscene.scene_stream",
        "rmscene.tagged_block_common",
        "rmscene.tagged_block_reader",
    ):
        logging.getLogger(rmscene_noisy).setLevel(logging.ERROR)

    processors: list = [
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.StackInfoRenderer(),
        structlog.processors.TimeStamper(fmt="iso", utc=True),
        # Convert exc_info=True into a formatted traceback string so it
        # ends up in the rendered output instead of being dropped.
        structlog.processors.format_exc_info,
    ]
    if json_output:
        processors.append(structlog.processors.JSONRenderer())
    else:
        processors.append(structlog.dev.ConsoleRenderer())

    structlog.configure(
        processors=processors,
        wrapper_class=structlog.make_filtering_bound_logger(log_level),
        cache_logger_on_first_use=True,
    )


def get(name: str | None = None) -> structlog.stdlib.BoundLogger:
    return structlog.get_logger(name)
