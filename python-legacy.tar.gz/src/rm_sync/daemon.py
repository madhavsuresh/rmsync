"""Top-level event loop.

Wires CloudPoller + LocalWatcher + N SyncWorkers around a shared queue.
Honors the pause sentinel and dry_run config flag. Caps initial-sync
concurrency by overriding RMAPI_CONCURRENT during the reconciliation step.
"""

from __future__ import annotations

import asyncio
import os
import signal
from pathlib import Path

from rm_sync.cloud import Cloud
from rm_sync.config import Config, IPC_SOCKET_PATH, RESYNC_DIR, STATE_DB_PATH, load
from rm_sync.echo_fence import EchoFence
from rm_sync.ipc import CommandRegistry, IPCServer, StateBus
from rm_sync.jobs import Job, JobKind
from rm_sync.locks import LockRegistry
from rm_sync.logging_setup import configure, get
from rm_sync.poller import CloudPoller
from rm_sync.state import State, open_state
from rm_sync.status import StatusWriter
from rm_sync.watcher import LocalWatcher
from rm_sync.worker import SyncWorker

log = get(__name__)

# rmapi concurrency to use during initial reconciliation (avoids stacking
# our pool * RMAPI_CONCURRENT default of 20).
INITIAL_SYNC_CONCURRENCY = 5


async def _reconcile_local_deletions(state: State, queue: asyncio.Queue[Job]) -> int:
    """Propagate deletions that happened while the daemon was off.

    The runtime watcher deliberately never propagates local deletes — FSEvents
    replays, atomic rename-via-tmp, and editor quirks make a single delete
    event an unreliable signal. At startup it's different: if a previously
    synced file isn't on disk now, it's been gone for at least the daemon's
    downtime — reliable enough to act on.

    Only acts on docs with ``last_synced_md_hash`` set (i.e. we have
    previously pulled or pushed this doc successfully). Docs that were only
    enqueued for pull but never completed are left alone.

    Must run BEFORE :py:func:`_initial_reconcile` so we don't pull cloud
    content just to immediately delete it.
    """
    enqueued = 0
    for doc in await state.all_documents():
        if doc.doc_type != "DocumentType":
            continue
        if not doc.last_synced_md_hash:
            continue  # never successfully synced; skip
        if Path(doc.local_path).exists():
            continue
        log.info(
            "local file missing on startup; propagating to cloud trash",
            doc_id=doc.doc_id,
            path=doc.local_path,
            remote=doc.remote_path,
        )
        await queue.put(
            Job(kind=JobKind.DELETE_REMOTE, doc_id=doc.doc_id, hint=doc.remote_path)
        )
        enqueued += 1
    if enqueued:
        log.info("startup deletion reconcile", enqueued=enqueued)
    return enqueued


async def _reconcile_local_creates_and_edits(
    state: State, cfg: Config, queue: asyncio.Queue[Job]
) -> int:
    """Find local .md files that appeared or changed while the daemon was off.

    Two cases:
      - New local file (no state row at that local_path) → push as new doc.
      - Existing tracked file whose on-disk hash differs from
        ``last_synced_md_hash`` → push as update.

    Ignores hidden dirs (``.rm-sync-trash``, ``.git``, etc.) and non-.md
    files. Must run AFTER :py:func:`_initial_reconcile` — otherwise a file
    that was pulled into the sync dir during this session would look
    "new" because its state row hasn't been written yet.
    """
    import hashlib

    enqueued = 0
    root = cfg.sync_dir
    if not root.exists():
        return 0

    for md in root.rglob("*.md"):
        # Same ignore rules as the watcher.
        try:
            rel = md.relative_to(root)
        except ValueError:
            continue
        if any(part.startswith(".") for part in rel.parts):
            continue
        if md.suffix == ".tmp" or md.name.endswith(".conflict"):
            continue

        local_path = str(md)
        stored = await state.by_local_path(local_path)
        try:
            text = md.read_text(encoding="utf-8")
        except OSError:
            continue
        current_hash = hashlib.sha256(text.encode("utf-8")).hexdigest()

        if stored is None:
            log.info("startup: local-only file, enqueuing push", path=local_path)
            await queue.put(Job(kind=JobKind.PUSH, doc_id=None, hint=local_path))
            enqueued += 1
        elif stored.last_synced_md_hash and stored.last_synced_md_hash != current_hash:
            log.info(
                "startup: local file edited while daemon was off",
                doc_id=stored.doc_id,
                path=local_path,
            )
            await queue.put(Job(kind=JobKind.PUSH, doc_id=stored.doc_id, hint=local_path))
            enqueued += 1
    if enqueued:
        log.info("startup local-change reconcile", enqueued=enqueued)
    return enqueued


async def _initial_reconcile(cloud: Cloud, cfg: Config, queue: asyncio.Queue[Job]) -> None:
    """Walk the remote tree once and enqueue PULL jobs for every document.
    Workers drain the queue; this returns when the queue is empty so the
    watcher can start without firing on the resulting writes.
    """
    log.info("initial reconcile: walking remote tree")
    nodes = await cloud.tree(f"/{cfg.remote_folder}")
    enqueued = 0
    for node in nodes:
        if node.type != "DocumentType":
            continue
        await queue.put(
            Job(kind=JobKind.PULL, doc_id=node.id, hint=node.remote_path)
        )
        enqueued += 1
    log.info("initial reconcile: enqueued", count=enqueued)
    # Wait for all initial pulls to complete before starting the watcher.
    await queue.join()
    log.info("initial reconcile: complete")


async def _run() -> None:
    cfg = load()
    configure(cfg.log.level)
    cfg.sync_dir.mkdir(parents=True, exist_ok=True)
    RESYNC_DIR.mkdir(parents=True, exist_ok=True)

    # Idempotent — returns fast after the first successful install.
    try:
        from rm_sync.native import macos as _native

        _native.ensure_folder_icon(cfg.sync_dir)
    except Exception:
        log.debug("ensure_folder_icon skipped")

    queue: asyncio.Queue[Job] = asyncio.Queue()
    fence = EchoFence(cfg.echo_fence_seconds)
    locks = LockRegistry()

    async with open_state(STATE_DB_PATH) as state:
        # Two cloud handles: one with capped concurrency for initial sync,
        # one with defaults for steady-state.
        cloud_initial = Cloud(concurrent_override=INITIAL_SYNC_CONCURRENCY)
        cloud_steady = Cloud()

        try:
            await cloud_steady.check_version()
        except Exception:
            log.exception("rmapi version check failed")

        # Workers handle the initial pull + any startup deletions.
        initial_workers = [
            SyncWorker(i, queue, cloud_initial, state, cfg, locks, fence)
            for i in range(cfg.worker_pool_size)
        ]
        worker_tasks = [asyncio.create_task(w.run()) for w in initial_workers]

        try:
            # 1. Propagate local deletions that happened while we were off,
            #    BEFORE pulling — otherwise initial_reconcile would re-pull
            #    the cloud copy of a file the user just deleted.
            await _reconcile_local_deletions(state, queue)
            await queue.join()
            # 2. Pull everything the cloud has that we haven't got.
            await _initial_reconcile(cloud_initial, cfg, queue)
            # 3. Push any local-only or locally-edited files that appeared
            #    while the daemon was off. Runs AFTER the pull so the state
            #    DB is up-to-date before we decide what's "new locally".
            await _reconcile_local_creates_and_edits(state, cfg, queue)
            await queue.join()
        except Exception:
            log.exception("initial reconcile failed; continuing into steady state")

        # Stop initial workers, start steady-state workers + poller + watcher.
        for w in initial_workers:
            w.stop()
        await asyncio.gather(*worker_tasks, return_exceptions=True)

        steady_workers = [
            SyncWorker(i, queue, cloud_steady, state, cfg, locks, fence)
            for i in range(cfg.worker_pool_size)
        ]
        worker_tasks = [asyncio.create_task(w.run()) for w in steady_workers]

        poller = CloudPoller(cloud_steady, state, cfg, queue, cfg.sync_dir)
        poller_task = asyncio.create_task(poller.run())

        watcher = LocalWatcher(cfg.sync_dir, queue, fence, cfg.debounce_seconds)
        watcher.start()

        # ── IPC: state bus + command registry + unix socket server ──
        bus = StateBus()
        registry = CommandRegistry()

        @registry.register("pause")
        async def _cmd_pause(_frame):
            await state.set_paused(True)
            await _refresh_status(state, cfg, queue, bus)
            return None

        @registry.register("resume")
        async def _cmd_resume(_frame):
            await state.set_paused(False)
            await _refresh_status(state, cfg, queue, bus)
            return None

        @registry.register("sync_now")
        async def _cmd_sync_now(_frame):
            poller.request_cycle()
            return None

        @registry.register("get_status")
        async def _cmd_get_status(_frame):
            await _refresh_status(state, cfg, queue, bus)
            return {"status": bus.snapshot().to_dict()}

        ipc_server = IPCServer(IPC_SOCKET_PATH, bus, registry)
        await ipc_server.start()

        # Status snapshot writer: pumps bus updates into both the
        # on-disk status.json (slow cadence, debug fallback) and
        # updates the bus on tick so long-idle stretches stay fresh.
        status_writer = StatusWriter(state, cfg, queue, bus=bus)
        status_task = asyncio.create_task(status_writer.run())

        stop = asyncio.Event()

        def _shutdown(*_: object) -> None:
            log.info("shutdown signal received")
            stop.set()

        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, _shutdown)

        await stop.wait()

        # Orderly shutdown
        watcher.stop()
        poller.stop()
        status_writer.stop()
        for w in steady_workers:
            w.stop()
        await ipc_server.stop()
        await asyncio.gather(
            poller_task, *worker_tasks, status_task, return_exceptions=True
        )


async def _refresh_status(
    state: State,
    cfg: Config,
    queue: asyncio.Queue[Job],
    bus: StateBus,
) -> None:
    """Populate the StateBus from the current DB state. Called after any
    command that could affect observable state (pause toggles, etc.)."""
    docs = await state.all_documents()
    tracked = sum(1 for d in docs if d.doc_type == "DocumentType")
    conflicts = sum(1 for d in docs if d.conflict_state == "unresolved")
    errors = sum(1 for d in docs if d.error_state is not None)
    last_pull = max((d.last_pull_at for d in docs if d.last_pull_at), default=None)
    last_push = max((d.last_push_at for d in docs if d.last_push_at), default=None)
    paused = await state.is_paused()
    current = bus.snapshot()
    # "state" follows queue + paused + error. Fall back to idle.
    if paused:
        new_state = "paused"
    elif current.last_error:
        new_state = "error"
    elif not queue.empty():
        new_state = "syncing"
    else:
        new_state = "idle"
    await bus.update(
        state=new_state,
        sync_dir=str(cfg.sync_dir),
        remote_folder=cfg.remote_folder,
        tracked_docs=tracked,
        conflicts=conflicts,
        errors=errors,
        queue_depth=queue.qsize(),
        last_pull_at=last_pull,
        last_push_at=last_push,
        paused=paused,
        pid=os.getpid(),
    )


def run() -> None:
    """Synchronous entry called by the CLI."""
    # Defer logging configure until we have config; bootstrap a default first.
    configure(level=os.environ.get("RM_SYNC_LOG_LEVEL", "INFO"))
    asyncio.run(_run())
