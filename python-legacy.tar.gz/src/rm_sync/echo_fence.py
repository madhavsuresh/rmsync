"""Suppress watchdog events that we caused ourselves.

When a worker writes a local file in response to a pull, the OS fires an
fsevent and watchdog wants to push it back. The fence is the first line of
defense: when the worker writes, it calls :py:meth:`mark`, and the watcher
calls :py:meth:`is_recent` before enqueuing.

The hash-equality check in the push path is the load-bearing second line of
defense (see worker.py). The fence is just an optimization to keep the queue
clean during normal operation.
"""

from __future__ import annotations

import time
from threading import Lock


class EchoFence:
    def __init__(self, window_seconds: float = 5.0) -> None:
        self.window = window_seconds
        self._stamps: dict[str, float] = {}
        self._lock = Lock()

    def mark(self, path: str) -> None:
        """Record that we just wrote ``path`` ourselves."""
        with self._lock:
            self._stamps[path] = time.monotonic()
            self._gc_locked()

    def is_recent(self, path: str) -> bool:
        """True if ``path`` was marked within the fence window."""
        with self._lock:
            ts = self._stamps.get(path)
            if ts is None:
                return False
            return (time.monotonic() - ts) <= self.window

    def _gc_locked(self) -> None:
        cutoff = time.monotonic() - self.window
        stale = [p for p, ts in self._stamps.items() if ts < cutoff]
        for p in stale:
            del self._stamps[p]
