"""Entry point: ``python -m rm_sync …`` delegates to the Click CLI."""

from rm_sync.cli import main

if __name__ == "__main__":
    main()
