"""Click CLI.

Subcommands beyond ``daemon`` are thin clients: they read SQLite in
``?mode=ro`` or touch sentinel files. No socket layer; see CHANGES_FROM_SPEC.md.
"""

from __future__ import annotations

import asyncio
import sqlite3
import sys
import time
from pathlib import Path

import click

from rm_sync import daemon as daemon_mod
from rm_sync import doctor
from rm_sync import ipc_client
from rm_sync.config import (
    CONFIG_PATH,
    LOG_DIR,
    RESYNC_DIR,
    STATE_DB_PATH,
    load,
)


@click.group()
@click.version_option()
def main() -> None:
    """rm-sync: bidirectional reMarkable ↔ Markdown sync."""


@main.command()
def daemon() -> None:
    """Run the long-running daemon (invoked by launchd; not for humans)."""
    daemon_mod.run()


@main.command()
def init() -> None:
    """One-time setup wizard. Re-runnable; idempotent."""
    click.echo("Run ./install.sh from the repo root.")
    click.echo("After that, edit ~/.config/rm-sync/config.toml and run `rm-sync doctor`.")


@main.command()
def status() -> None:
    """Print daemon health + outstanding work."""
    try:
        cfg = load()
    except Exception as e:
        click.echo(f"config: NOT LOADED ({e})")
        return

    # Try IPC first for a live snapshot.
    live = ipc_client.get_status()
    if live is not None:
        click.echo(f"sync dir:       {live.get('sync_dir')}")
        click.echo(f"remote folder:  /{live.get('remote_folder')}")
        click.echo(f"push strategy:  {cfg.push_strategy}")
        click.echo(f"state:          {live.get('state')}")
        click.echo(f"paused:         {live.get('paused')}")
        click.echo(f"tracked docs:   {live.get('tracked_docs')}")
        click.echo(f"conflicts:      {live.get('conflicts')}")
        click.echo(f"parked errors:  {live.get('errors')}")
        click.echo(f"queue depth:    {live.get('queue_depth')}")
        click.echo(f"last pull:      {live.get('last_pull_at') or '(never)'}")
        click.echo(f"last push:      {live.get('last_push_at') or '(never)'}")
        return

    # Fallback: read DB directly.
    click.echo(f"sync dir:       {cfg.sync_dir}")
    click.echo(f"remote folder:  /{cfg.remote_folder}")
    click.echo(f"push strategy:  {cfg.push_strategy}")
    click.echo("daemon:         not running (reading state DB directly)")

    if not STATE_DB_PATH.exists():
        click.echo("state DB:       (not initialized)")
        return

    conn = sqlite3.connect(f"file:{STATE_DB_PATH}?mode=ro", uri=True)
    try:
        conn.row_factory = sqlite3.Row
        total = conn.execute("SELECT COUNT(*) AS c FROM documents").fetchone()["c"]
        conflicts = conn.execute(
            "SELECT COUNT(*) AS c FROM documents WHERE conflict_state IS NOT NULL"
        ).fetchone()["c"]
        errors = conn.execute(
            "SELECT COUNT(*) AS c FROM documents WHERE error_state IS NOT NULL"
        ).fetchone()["c"]
        last_pull = conn.execute(
            "SELECT MAX(last_pull_at) AS m FROM documents"
        ).fetchone()["m"]

        click.echo(f"tracked docs:   {total}")
        click.echo(f"conflicts:      {conflicts}")
        click.echo(f"parked errors:  {errors}")
        click.echo(f"last pull:      {last_pull or '(never)'}")

        recent = conn.execute(
            "SELECT ts, level, doc_id, message FROM sync_log ORDER BY id DESC LIMIT 10"
        ).fetchall()
        if recent:
            click.echo("\nrecent log:")
            for row in recent:
                click.echo(
                    f"  {row['ts']}  {row['level']:<7}  "
                    f"{(row['doc_id'] or '')[:8]:<8}  {row['message']}"
                )
    finally:
        conn.close()


@main.command()
@click.option("-f", "--follow", is_flag=True, help="Tail the log")
def logs(follow: bool) -> None:
    """Tail the daemon's stderr log."""
    log_file = LOG_DIR / "stderr.log"
    if not log_file.exists():
        click.echo(f"no log file at {log_file}")
        sys.exit(1)
    if not follow:
        click.echo(log_file.read_text())
        return
    with log_file.open("r") as f:
        f.seek(0, 2)
        try:
            while True:
                line = f.readline()
                if line:
                    click.echo(line, nl=False)
                else:
                    time.sleep(0.5)
        except KeyboardInterrupt:
            pass


@main.command()
def pause() -> None:
    """Tell the daemon to stop syncing."""
    _set_paused(True, friendly_verb="paused")


@main.command()
def resume() -> None:
    """Resume syncing."""
    _set_paused(False, friendly_verb="resumed")


@main.command("sync-now")
def sync_now() -> None:
    """Trigger an immediate poll cycle (menu bar's \u201cSync Now\u201d from the CLI)."""
    try:
        ipc_client.request("sync_now")
        click.echo("sync requested")
    except ipc_client.IPCUnavailable:
        click.echo("daemon not running; start it with `rm-sync start`.", err=True)
        sys.exit(1)


def _set_paused(paused: bool, *, friendly_verb: str) -> None:
    """Set the paused flag. Prefer IPC; fall back to writing the DB
    directly when the daemon is down (so the setting is picked up on next
    daemon start)."""
    try:
        ipc_client.request("pause" if paused else "resume")
        click.echo(friendly_verb)
        return
    except ipc_client.IPCUnavailable:
        pass

    # Daemon not running — poke the DB directly.
    if not STATE_DB_PATH.exists():
        click.echo(
            "daemon not running and no state DB yet; start the daemon first.",
            err=True,
        )
        sys.exit(1)
    conn = sqlite3.connect(STATE_DB_PATH)
    try:
        conn.execute(
            "INSERT OR REPLACE INTO settings(key, value) VALUES (?, ?)",
            ("paused", "1" if paused else "0"),
        )
        conn.commit()
    finally:
        conn.close()
    click.echo(f"{friendly_verb} (daemon not running; will apply on next start)")


@main.command()
def conflicts() -> None:
    """List unresolved conflicts."""
    if not STATE_DB_PATH.exists():
        click.echo("no state DB")
        return
    conn = sqlite3.connect(f"file:{STATE_DB_PATH}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            "SELECT doc_id, local_path FROM documents WHERE conflict_state='unresolved'"
        ).fetchall()
        if not rows:
            click.echo("no unresolved conflicts")
            return
        for r in rows:
            md = Path(r["local_path"])
            cf = md.with_suffix(md.suffix + ".conflict")
            click.echo(f"{r['doc_id']}")
            click.echo(f"  live:     {md}")
            click.echo(f"  conflict: {cf} {'(present)' if cf.exists() else '(MISSING)'}")
    finally:
        conn.close()


@main.command()
@click.argument("path")
def resync(path: str) -> None:
    """Drop a marker so the daemon force-pulls a doc/subtree on its next cycle."""
    RESYNC_DIR.mkdir(parents=True, exist_ok=True)
    marker = RESYNC_DIR / path.replace("/", "_")
    marker.write_text(path)
    click.echo(f"queued resync: {path} (marker: {marker})")


@main.command(name="doctor")
def doctor_cmd() -> None:
    """Run all self-checks."""
    sys.exit(doctor.main_sync())


@main.command()
def start() -> None:
    """Start the launchd agent (idempotent)."""
    if _daemon_running():
        click.echo("already running")
        return
    if not _agent_plist_path().exists():
        click.echo(
            f"ERROR: no plist at {_agent_plist_path()}. Run ./install.sh first.",
            err=True,
        )
        sys.exit(1)
    if _start_agent():
        click.echo("started")
    else:
        click.echo("failed to start; check `rm-sync logs`", err=True)
        sys.exit(1)


@main.command()
def stop() -> None:
    """Stop the launchd agent (idempotent)."""
    if _stop_agent():
        click.echo("stopped")
    else:
        click.echo("was not running")


@main.command()
def restart() -> None:
    """Kick the launchd agent — fast path for picking up code changes."""
    import subprocess

    if not _daemon_running():
        # Not loaded at all; bootstrap fresh.
        if _start_agent():
            click.echo("started")
            return
        click.echo("failed to start; check `rm-sync logs`", err=True)
        sys.exit(1)
    # Loaded; kickstart -k replaces the running instance.
    p = subprocess.run(
        ["launchctl", "kickstart", "-k", f"gui/{_uid()}/com.user.rmsync"],
        capture_output=True,
        text=True,
    )
    if p.returncode != 0:
        click.echo(
            f"kickstart failed: {p.stderr.strip() or p.stdout.strip()}",
            err=True,
        )
        sys.exit(1)
    click.echo("restarted")


@main.command()
@click.argument("new_sync_dir")
@click.option(
    "--force",
    is_flag=True,
    help="Allow merging into a non-empty target directory.",
)
@click.option(
    "--keep-stopped",
    is_flag=True,
    help="Leave the launchd agent stopped after relocating (default restarts it).",
)
def relocate(new_sync_dir: str, force: bool, keep_stopped: bool) -> None:
    """Move the sync dir to a new location, rewriting state + config.

    Handles the full dance: stops the launchd agent if running, moves the
    files, rewrites state DB paths, updates config, and restarts the
    agent. Typical use is pointing the sync dir at a Dropbox or iCloud
    Drive folder for cross-device access.
    """
    import os
    import re as _re
    import shutil

    try:
        cfg = load()
    except Exception as e:
        click.echo(f"config: NOT LOADED ({e})", err=True)
        sys.exit(1)

    old = cfg.sync_dir.resolve()
    new = Path(new_sync_dir).expanduser().resolve()

    if new == old:
        click.echo(f"sync_dir is already {new}; nothing to do.")
        return

    if new.exists() and any(new.glob("*.md")) and not force:
        click.echo(
            f"ERROR: {new} already contains .md files. Pass --force to merge.",
            err=True,
        )
        sys.exit(1)

    # 0. Stop the daemon if it's loaded (idempotent).
    was_running = _stop_agent()
    if was_running:
        click.echo("  stopped launchd agent")

    # 1. Move the tree.
    new.parent.mkdir(parents=True, exist_ok=True)
    if old.exists():
        if new.exists():
            # Merge: move each entry individually.
            for child in old.iterdir():
                dest = new / child.name
                if dest.exists():
                    click.echo(f"  skipping (already exists): {dest}")
                    continue
                shutil.move(str(child), str(dest))
            try:
                old.rmdir()
            except OSError:
                pass
        else:
            shutil.move(str(old), str(new))
        click.echo(f"  moved {old} -> {new}")
    else:
        new.mkdir(parents=True, exist_ok=True)
        click.echo(f"  old sync dir didn't exist; created {new}")

    # 2. Rewrite state DB local_path column.
    if STATE_DB_PATH.exists():
        conn = sqlite3.connect(STATE_DB_PATH)
        try:
            old_prefix = str(old) + os.sep
            new_prefix = str(new) + os.sep
            cur = conn.execute("SELECT doc_id, local_path FROM documents")
            rewrites = []
            for row in cur.fetchall():
                doc_id, lp = row
                if lp and lp.startswith(old_prefix):
                    rewrites.append((new_prefix + lp[len(old_prefix) :], doc_id))
                elif lp == str(old):
                    rewrites.append((str(new), doc_id))
            for new_lp, doc_id in rewrites:
                conn.execute(
                    "UPDATE documents SET local_path=? WHERE doc_id=?",
                    (new_lp, doc_id),
                )
            conn.commit()
            click.echo(f"  rewrote {len(rewrites)} state row(s)")
        finally:
            conn.close()

    # 3. Rewrite config.toml's sync_dir line in place.
    if CONFIG_PATH.exists():
        original = CONFIG_PATH.read_text()
        # Preserve the user's quoting style; swap the value only.
        pattern = _re.compile(r'^(\s*sync_dir\s*=\s*)"[^"]*"', _re.MULTILINE)
        new_text, n = pattern.subn(rf'\g<1>"{new}"', original, count=1)
        if n == 0:
            new_text = original.rstrip() + f'\nsync_dir = "{new}"\n'
        CONFIG_PATH.write_text(new_text)
        click.echo(f"  config.toml updated ({CONFIG_PATH})")

    # 4. Restart the agent unless the user opted out.
    if keep_stopped:
        click.echo(
            "\nDone. Agent left stopped. Restart with:\n"
            "  launchctl bootstrap gui/$(id -u) "
            "~/Library/LaunchAgents/com.user.rmsync.plist"
        )
        return

    if _start_agent():
        click.echo("  started launchd agent")
        click.echo(f"\nDone. Sync dir is now {new}.")
    else:
        click.echo(
            "\nMove succeeded but agent didn't start. Check:\n"
            "  launchctl print gui/$(id -u)/com.user.rmsync\n"
            "  tail ~/Library/Logs/rm-sync/stdout.log",
            err=True,
        )


# ---- launchd helpers -------------------------------------------------------

def _uid() -> int:
    import os as _os

    return _os.getuid()


def _agent_plist_path() -> Path:
    return Path.home() / "Library/LaunchAgents/com.user.rmsync.plist"


def _daemon_running() -> bool:
    import subprocess

    p = subprocess.run(
        ["launchctl", "print", f"gui/{_uid()}/com.user.rmsync"],
        capture_output=True,
        text=True,
    )
    if p.returncode != 0:
        return False
    out = p.stdout
    return "state = running" in out or "state = waiting" in out


def _stop_agent() -> bool:
    """Bootout the agent if it's loaded. Returns True if it was stopped,
    False if it wasn't loaded to begin with (not an error).

    launchctl bootout returns exit code 3 when the service isn't loaded.
    We treat that as success-of-intent — the end state we want (not
    running) is already achieved.
    """
    import subprocess

    if not _daemon_running():
        return False
    p = subprocess.run(
        ["launchctl", "bootout", f"gui/{_uid()}/com.user.rmsync"],
        capture_output=True,
        text=True,
    )
    if p.returncode not in (0, 3):
        raise click.ClickException(
            f"launchctl bootout failed: {p.stderr.strip() or p.stdout.strip()}"
        )
    # Wait briefly for the process to exit.
    import time as _t

    for _ in range(20):  # up to 2s
        if not _daemon_running():
            break
        _t.sleep(0.1)
    return True


def _start_agent() -> bool:
    """Bootstrap the agent. Returns True on success.

    Retries with a short backoff — launchd sometimes reports bootstrap
    failure when it's still tearing down a prior instance of the same
    label, especially when stop→start happens back-to-back.
    """
    import subprocess
    import time as _t

    plist = _agent_plist_path()
    if not plist.exists():
        return False
    if _daemon_running():
        return True
    last_err = ""
    for attempt in range(4):
        p = subprocess.run(
            ["launchctl", "bootstrap", f"gui/{_uid()}", str(plist)],
            capture_output=True,
            text=True,
        )
        if p.returncode == 0 or _daemon_running():
            return True
        last_err = p.stderr.strip() or p.stdout.strip()
        _t.sleep(0.25 * (attempt + 1))
    if last_err:
        # Surface the error so `rm-sync start` doesn't fail silently.
        import click as _click

        _click.echo(f"launchctl bootstrap: {last_err}", err=True)
    return False


@main.command()
def uninstall() -> None:
    """Remove the launchd agent. Run scripts/uninstall.sh for full cleanup."""
    click.echo("Run ./uninstall.sh (or ./uninstall.sh --purge) from the repo root.")


if __name__ == "__main__":
    main()
