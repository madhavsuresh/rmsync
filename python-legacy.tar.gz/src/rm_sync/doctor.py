"""Self-checks for ``rm-sync doctor``.

Each check returns a (status, message) pair. Exit code is 0 only when every
check is 'ok' or 'warn'; any 'fail' returns 1.

Spec check #10 (subscription/inactivity heuristic) is dropped — it produces
noise and can't reliably distinguish subscription expiry from "user just
doesn't edit old notes."
"""

from __future__ import annotations

import asyncio
import os
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Awaitable, Callable, Literal

from rm_sync.cloud import RMAPI_MAX_EXCLUSIVE, RMAPI_MIN, Cloud
from rm_sync.config import LOG_DIR, STATE_DB_PATH, load
from rm_sync.state import open_state

Status = Literal["ok", "warn", "fail"]


@dataclass
class CheckResult:
    name: str
    status: Status
    message: str


CheckFn = Callable[[], Awaitable[CheckResult]]


async def _check_rmapi_present() -> CheckResult:
    if shutil.which("rmapi") is None:
        return CheckResult("rmapi on PATH", "fail", "rmapi not found")
    return CheckResult("rmapi on PATH", "ok", shutil.which("rmapi") or "")


async def _check_rmapi_version() -> CheckResult:
    try:
        v = await Cloud().version()
    except Exception as e:
        return CheckResult("rmapi version", "fail", str(e))
    if not (RMAPI_MIN <= v < RMAPI_MAX_EXCLUSIVE):
        return CheckResult(
            "rmapi version",
            "warn",
            f"{'.'.join(map(str, v))} outside tested range "
            f"[{'.'.join(map(str, RMAPI_MIN))}, {'.'.join(map(str, RMAPI_MAX_EXCLUSIVE))})",
        )
    return CheckResult("rmapi version", "ok", ".".join(map(str, v)))


async def _check_rmapi_authed() -> CheckResult:
    try:
        await Cloud().find("/")
    except Exception as e:
        return CheckResult(
            "rmapi authenticated",
            "fail",
            f"`rmapi find /` failed: {e}. Run `rmapi` once to authenticate.",
        )
    return CheckResult("rmapi authenticated", "ok", "")


async def _check_writing_folder() -> CheckResult:
    try:
        cfg = load()
    except Exception as e:
        return CheckResult("Writing folder", "fail", f"config load failed: {e}")
    try:
        await Cloud().find(f"/{cfg.remote_folder}")
    except Exception as e:
        return CheckResult(
            "Writing folder",
            "fail",
            f"`rmapi find /{cfg.remote_folder}` failed: {e}",
        )
    return CheckResult("Writing folder", "ok", cfg.remote_folder)


async def _check_sync_dir() -> CheckResult:
    try:
        cfg = load()
    except Exception as e:
        return CheckResult("sync_dir", "fail", str(e))
    p: Path = cfg.sync_dir
    if not p.exists():
        return CheckResult("sync_dir", "warn", f"{p} doesn't exist (will be created)")
    if not os.access(p, os.W_OK):
        return CheckResult("sync_dir", "fail", f"{p} not writable")
    if p.is_symlink():
        target = p.resolve()
        return CheckResult("sync_dir", "warn", f"symlink → {target}")
    return CheckResult("sync_dir", "ok", str(p))


async def _check_state_db() -> CheckResult:
    if not STATE_DB_PATH.exists():
        return CheckResult("state DB", "warn", "no state DB yet (first run)")
    try:
        async with open_state(STATE_DB_PATH) as state:
            await state.all_documents()
    except Exception as e:
        return CheckResult("state DB", "fail", str(e))
    return CheckResult("state DB", "ok", str(STATE_DB_PATH))


async def _check_launchd_loaded() -> CheckResult:
    try:
        p = subprocess.run(
            ["launchctl", "print", f"gui/{os.getuid()}/com.user.rmsync"],
            capture_output=True,
            text=True,
            timeout=5,
        )
    except FileNotFoundError:
        return CheckResult("launchd plist loaded", "warn", "launchctl not on PATH")
    except subprocess.TimeoutExpired:
        return CheckResult("launchd plist loaded", "warn", "launchctl print timed out")
    if p.returncode != 0:
        return CheckResult(
            "launchd plist loaded",
            "fail",
            "agent not loaded; run install.sh",
        )
    return CheckResult("launchd plist loaded", "ok", "")


async def _check_disk_space() -> CheckResult:
    try:
        cfg = load()
        usage = shutil.disk_usage(cfg.sync_dir if cfg.sync_dir.exists() else cfg.sync_dir.parent)
    except Exception as e:
        return CheckResult("disk space", "warn", str(e))
    free_gb = usage.free / (1024**3)
    if free_gb < 1:
        return CheckResult("disk space", "fail", f"{free_gb:.2f} GB free")
    return CheckResult("disk space", "ok", f"{free_gb:.1f} GB free")


async def _check_log_dir() -> CheckResult:
    if not LOG_DIR.exists():
        return CheckResult("log dir", "warn", f"{LOG_DIR} doesn't exist")
    if not os.access(LOG_DIR, os.W_OK):
        return CheckResult("log dir", "fail", f"{LOG_DIR} not writable")
    return CheckResult("log dir", "ok", str(LOG_DIR))


async def _check_clock_skew() -> CheckResult:
    # Cheap proxy: check that `date` produces a sensible recent year.
    # A real NTP query is nice-to-have; macOS time is generally trustworthy.
    import time as _t

    if abs(_t.time() - _t.time()) > 0:  # placeholder
        pass
    return CheckResult("clock", "ok", "skipped (relying on macOS time sync)")


CHECKS: list[CheckFn] = [
    _check_rmapi_present,
    _check_rmapi_version,
    _check_rmapi_authed,
    _check_writing_folder,
    _check_sync_dir,
    _check_state_db,
    _check_launchd_loaded,
    _check_disk_space,
    _check_log_dir,
    _check_clock_skew,
]


async def run_all() -> list[CheckResult]:
    return [await fn() for fn in CHECKS]


def main_sync() -> int:
    results = asyncio.run(run_all())
    has_fail = False
    for r in results:
        marker = {"ok": "✓", "warn": "!", "fail": "✗"}[r.status]
        print(f"  {marker} {r.name:<24} {r.message}")
        if r.status == "fail":
            has_fail = True
    return 1 if has_fail else 0
