"""Synchronous Unix-socket client used by the CLI.

Purpose: one-shot request/response without spinning up asyncio. The CLI
runs in a subprocess for every invocation, so the overhead of opening a
socket, sending one frame, and waiting for the ack is acceptable (it's
the same order as forking `launchctl`).

If the daemon isn't running (socket missing or connect refused), the
caller falls back to reading SQLite directly.
"""

from __future__ import annotations

import json
import socket
import uuid
from pathlib import Path
from typing import Any

from rm_sync.config import IPC_SOCKET_PATH


class IPCUnavailable(RuntimeError):
    """The daemon isn't accepting IPC connections right now."""


def _connect(timeout: float = 0.5, path: Path | None = None) -> socket.socket:
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(timeout)
    try:
        s.connect(str(path or IPC_SOCKET_PATH))
    except (FileNotFoundError, ConnectionRefusedError, OSError) as e:
        s.close()
        raise IPCUnavailable(str(e)) from e
    return s


def _read_frame(f) -> dict[str, Any]:
    line = f.readline()
    if not line:
        raise IPCUnavailable("daemon closed connection")
    return json.loads(line)


def request(command: str, timeout: float = 2.0, **extra: Any) -> dict[str, Any]:
    """Send one command and return the ack payload.

    Raises ``IPCUnavailable`` if the daemon is down.

    Returns the ack dict (minus ``type``/``id`` bookkeeping). Raises
    ``RuntimeError`` if the daemon acked with ``ok=false``.
    """
    s = _connect(timeout=timeout)
    s.settimeout(timeout)
    try:
        f = s.makefile("rwb", buffering=0)
        # First frame from the server is hello. Consume and discard.
        hello = _read_frame(f)
        if hello.get("type") != "hello":
            raise IPCUnavailable(f"unexpected first frame: {hello!r}")

        req_id = uuid.uuid4().hex[:8]
        frame = {"id": req_id, "type": command, **extra}
        f.write((json.dumps(frame) + "\n").encode("utf-8"))

        # Read frames until we see our ack. Skip unrelated broadcasts.
        while True:
            resp = _read_frame(f)
            if resp.get("type") == "ack" and resp.get("id") == req_id:
                if not resp.get("ok", False):
                    raise RuntimeError(resp.get("error", "command failed"))
                return resp
    finally:
        try:
            s.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        s.close()


def get_status(timeout: float = 0.5) -> dict[str, Any] | None:
    """Return the daemon's current status, or None if the daemon is down."""
    try:
        resp = request("get_status", timeout=timeout)
    except IPCUnavailable:
        return None
    return resp.get("status")


def is_daemon_up(timeout: float = 0.2) -> bool:
    try:
        s = _connect(timeout=timeout)
    except IPCUnavailable:
        return False
    s.close()
    return True
