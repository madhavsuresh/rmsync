"""rm-sync: bidirectional reMarkable ↔ Markdown daemon for macOS."""

__version__ = "0.1.0"
