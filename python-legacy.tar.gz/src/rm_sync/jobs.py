"""Job records flowing through the worker queue."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class JobKind(str, Enum):
    PULL = "pull"
    PUSH = "push"
    DELETE_REMOTE = "delete_remote"
    DELETE_LOCAL = "delete_local"
    RENAME_REMOTE = "rename_remote"


@dataclass
class Job:
    kind: JobKind
    doc_id: str | None
    # For PULL/PUSH/RENAME, ``hint`` carries the remote path or local path that
    # triggered the job. For new-document PUSH (no doc_id yet), the hint is
    # the local path of the newly created .md.
    hint: str = ""
