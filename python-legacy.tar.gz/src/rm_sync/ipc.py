"""Daemon-side IPC: Unix-socket server + broadcast bus.

Protocol: newline-delimited JSON over AF_UNIX / SOCK_STREAM. Each client
sees:
  1. A ``hello`` frame with the current status immediately after connect.
  2. A stream of ``status`` broadcasts whenever the daemon state transitions.
  3. Acks for any request frames the client sends.

Clients may interleave requests and broadcasts on the same connection.
"""

from __future__ import annotations

import asyncio
import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Awaitable, Callable

from rm_sync.logging_setup import get

log = get(__name__)


# ---- state bus --------------------------------------------------------------


@dataclass
class Status:
    """Snapshot of the daemon state sent as the JSON payload in broadcasts.

    This mirrors the legacy ``status.json`` schema so the CLI fallback
    (which may still read the on-disk file) sees identical fields.
    """

    state: str = "idle"                         # idle|syncing|paused|error|stopped
    sync_dir: str = ""
    remote_folder: str = ""
    tracked_docs: int = 0
    conflicts: int = 0
    errors: int = 0
    queue_depth: int = 0
    last_pull_at: str | None = None
    last_push_at: str | None = None
    last_error: str | None = None
    paused: bool = False
    updated_at: str = ""
    pid: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "state": self.state,
            "sync_dir": self.sync_dir,
            "remote_folder": self.remote_folder,
            "tracked_docs": self.tracked_docs,
            "conflicts": self.conflicts,
            "errors": self.errors,
            "queue_depth": self.queue_depth,
            "last_pull_at": self.last_pull_at,
            "last_push_at": self.last_push_at,
            "last_error": self.last_error,
            "paused": self.paused,
            "updated_at": self.updated_at,
            "pid": self.pid,
        }


class StateBus:
    """Holds the current daemon status and broadcasts transitions to clients.

    The daemon treats this as its single source of truth for "what are we
    currently showing to UIs". Every pull/push worker, the poller, and the
    pause handler update it; connected IPC clients get a broadcast on
    every change.
    """

    def __init__(self) -> None:
        self._status = Status()
        self._subscribers: set[asyncio.Queue[dict[str, Any]]] = set()
        self._lock = asyncio.Lock()

    def snapshot(self) -> Status:
        return Status(**vars(self._status))

    async def update(self, **fields: Any) -> None:
        async with self._lock:
            for key, value in fields.items():
                setattr(self._status, key, value)
            self._status.updated_at = datetime.now(timezone.utc).isoformat()
            payload = {"type": "status", **self._status.to_dict()}
        self._fanout(payload)

    def subscribe(self) -> asyncio.Queue[dict[str, Any]]:
        q: asyncio.Queue[dict[str, Any]] = asyncio.Queue(maxsize=32)
        self._subscribers.add(q)
        return q

    def unsubscribe(self, q: asyncio.Queue[dict[str, Any]]) -> None:
        self._subscribers.discard(q)

    def _fanout(self, payload: dict[str, Any]) -> None:
        # Drop slow clients rather than blocking the broadcaster.
        for q in list(self._subscribers):
            try:
                q.put_nowait(payload)
            except asyncio.QueueFull:
                log.warning("ipc client queue full; dropping frame")


# ---- command handler --------------------------------------------------------


# A command handler returns either None (ack ok) or a dict (ack with extra
# fields, or an "ok": False + error message).
CommandHandler = Callable[[dict[str, Any]], Awaitable[dict[str, Any] | None]]


@dataclass
class CommandRegistry:
    handlers: dict[str, CommandHandler] = field(default_factory=dict)

    def register(self, name: str) -> Callable[[CommandHandler], CommandHandler]:
        def _decorator(fn: CommandHandler) -> CommandHandler:
            self.handlers[name] = fn
            return fn
        return _decorator

    async def dispatch(self, name: str, frame: dict[str, Any]) -> dict[str, Any]:
        handler = self.handlers.get(name)
        if handler is None:
            return {"ok": False, "error": f"unknown command: {name}"}
        try:
            extra = await handler(frame) or {}
        except Exception as e:
            log.exception("ipc handler crashed", command=name)
            return {"ok": False, "error": str(e)}
        base: dict[str, Any] = {"ok": True}
        base.update(extra)
        return base


# ---- server -----------------------------------------------------------------


class IPCServer:
    """asyncio Unix-socket server. One task per client."""

    def __init__(
        self,
        socket_path: Path,
        bus: StateBus,
        registry: CommandRegistry,
    ):
        self.socket_path = socket_path
        self.bus = bus
        self.registry = registry
        self._server: asyncio.AbstractServer | None = None

    async def start(self) -> None:
        # Unlink any stale socket from a prior crashed run.
        try:
            self.socket_path.unlink()
        except FileNotFoundError:
            pass
        self.socket_path.parent.mkdir(parents=True, exist_ok=True)

        self._server = await asyncio.start_unix_server(
            self._handle_client,
            path=str(self.socket_path),
        )
        # Tighten permissions to owner-only.
        try:
            os.chmod(self.socket_path, 0o600)
        except OSError:
            pass
        log.info("ipc server listening", path=str(self.socket_path))

    async def stop(self) -> None:
        if self._server is not None:
            self._server.close()
            await self._server.wait_closed()
            self._server = None
        try:
            self.socket_path.unlink()
        except FileNotFoundError:
            pass
        log.info("ipc server stopped")

    async def _handle_client(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        q = self.bus.subscribe()
        peer = writer.get_extra_info("peername") or "<local>"
        log.debug("ipc client connected", peer=str(peer))

        # Send hello with current status immediately.
        hello = {"type": "hello", "status": self.bus.snapshot().to_dict()}
        await _write_frame(writer, hello)

        broadcast_task = asyncio.create_task(_pump_broadcasts(q, writer))
        try:
            while True:
                line = await reader.readline()
                if not line:
                    break
                try:
                    frame = json.loads(line.decode("utf-8"))
                except json.JSONDecodeError:
                    await _write_frame(
                        writer,
                        {"type": "ack", "ok": False, "error": "invalid json"},
                    )
                    continue
                await self._dispatch_frame(frame, writer)
        except (ConnectionResetError, BrokenPipeError):
            pass
        finally:
            broadcast_task.cancel()
            self.bus.unsubscribe(q)
            writer.close()
            try:
                await writer.wait_closed()
            except (ConnectionResetError, BrokenPipeError):
                pass
            log.debug("ipc client disconnected", peer=str(peer))

    async def _dispatch_frame(
        self,
        frame: dict[str, Any],
        writer: asyncio.StreamWriter,
    ) -> None:
        cmd = frame.get("type")
        req_id = frame.get("id")
        if cmd is None:
            return
        if cmd == "ack" or cmd == "status" or cmd == "hello":
            return  # server-only frames
        result = await self.registry.dispatch(cmd, frame)
        await _write_frame(writer, {"type": "ack", "id": req_id, **result})


async def _pump_broadcasts(
    queue: asyncio.Queue[dict[str, Any]],
    writer: asyncio.StreamWriter,
) -> None:
    try:
        while True:
            payload = await queue.get()
            await _write_frame(writer, payload)
    except (ConnectionResetError, BrokenPipeError, asyncio.CancelledError):
        return


async def _write_frame(
    writer: asyncio.StreamWriter,
    payload: dict[str, Any],
) -> None:
    data = (json.dumps(payload) + "\n").encode("utf-8")
    writer.write(data)
    try:
        await writer.drain()
    except (ConnectionResetError, BrokenPipeError):
        pass
