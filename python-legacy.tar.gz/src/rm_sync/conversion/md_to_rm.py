"""Markdown → reMarkable v6 .rm.

Three strategies, picked by ``config.push_strategy``:

  - ``native_plain`` (default, recommended): plain typed text. Uses
    rmscene's verified ``simple_text_document``. Formatting is dropped on
    push — ``# Heading`` becomes literal ``# Heading`` characters on the
    tablet. Round-trip is byte-stable for plain content.
  - ``native_formatted``: builds CRDT structures with paragraph styles and
    span properties. rmscene's writer for formatted CRDT sequences is
    marked experimental. Callers MUST round-trip-validate every push and
    park documents that fail validation.
  - ``pdf``: render Markdown to PDF and upload as a PDF document. Tablet
    sees a read-only document. Useful for reference material only.
"""

from __future__ import annotations

import uuid as _uuid
from io import BytesIO

from rmscene import simple_text_document, write_blocks  # type: ignore[import-untyped]


def page_native_plain(text: str, *, author_uuid: str | None = None) -> bytes:
    """Strategy A. Verified round-trip for plain text.

    ``author_uuid`` must be stable across successive pushes of the same doc.
    If different UUIDs are used, the tablet's CRDT engine interleaves each
    push with the prior version instead of replacing — observed as
    character-doubled text on the tablet. Callers should obtain the UUID
    from :py:meth:`state.State.get_or_create_author_uuid`.
    """
    author = _uuid.UUID(author_uuid) if author_uuid else None
    buf = BytesIO()
    write_blocks(buf, simple_text_document(text or "", author_uuid=author))
    return buf.getvalue()


def page_native_formatted(markdown: str) -> bytes:
    """Strategy B. EXPERIMENTAL — caller must round-trip validate.

    TODO: implement formatted CRDT sequence construction. Until then this
    raises so a misconfigured daemon fails loudly rather than silently
    producing invalid files.
    """
    raise NotImplementedError(
        "native_formatted writer not yet implemented; use native_plain"
    )


def page_pdf(markdown: str) -> bytes:
    """Strategy C. Renders to PDF via pandoc (optional dependency)."""
    try:
        import pypandoc  # type: ignore[import-not-found]
    except ImportError as e:  # pragma: no cover
        raise RuntimeError(
            "pdf strategy requires the 'pdf' extra: pip install rm-sync[pdf]"
        ) from e
    return pypandoc.convert_text(markdown, to="pdf", format="md", extra_args=["--pdf-engine=weasyprint"])
