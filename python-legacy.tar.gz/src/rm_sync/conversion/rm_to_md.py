"""Convert a v6 .rm file's typed-text CRDT to Markdown.

Pages with no typed-text content (handwriting-only) yield an empty string.

Note: under the default ``native_plain`` push strategy, formatting prefixes
(``# ``, ``- ``, ``**bold**``) emitted here are *lost on the next push*.
This is intentional and documented; users who want round-trip formatting
must opt into ``native_formatted`` and accept the experimental writer.
"""

from __future__ import annotations

from io import BytesIO

# rmscene's public surface differs across 0.x versions. Import lazily and
# tolerate slight reshuffles by name.
from rmscene import read_tree  # type: ignore[import-untyped]
from rmscene.scene_items import ParagraphStyle  # type: ignore[import-untyped]
from rmscene.text import TextDocument  # type: ignore[import-untyped]

from rm_sync.logging_setup import get

log = get(__name__)


_STYLE_PREFIX: dict[ParagraphStyle, str] = {
    ParagraphStyle.PLAIN: "",
    ParagraphStyle.BASIC: "",
    ParagraphStyle.HEADING: "# ",
    ParagraphStyle.BOLD: "## ",
    ParagraphStyle.BULLET: "- ",
    ParagraphStyle.BULLET2: "  - ",
    ParagraphStyle.CHECKBOX: "- [ ] ",
    ParagraphStyle.CHECKBOX_CHECKED: "- [x] ",
}


class RmParseError(RuntimeError):
    """rmscene failed on a .rm file. Caller should park the document."""


def page_to_markdown(rm_bytes: bytes) -> str:
    """Parse one .rm page and return Markdown. Empty string if no typed text."""
    try:
        tree = read_tree(BytesIO(rm_bytes))
    except Exception as e:  # rmscene raises a variety of types
        raise RmParseError(str(e)) from e

    if getattr(tree, "root_text", None) is None:
        return ""

    try:
        doc = TextDocument.from_scene_item(tree.root_text)
    except Exception as e:
        raise RmParseError(f"text document extract failed: {e}") from e

    lines: list[str] = []
    for para in doc.contents:
        style = para.style.value if para.style else ParagraphStyle.PLAIN
        prefix = _STYLE_PREFIX.get(style, "")
        rendered = _render_spans(para.contents)
        if rendered or prefix:
            lines.append(prefix + rendered)
    return "\n".join(lines) + ("\n" if lines else "")


def _render_spans(spans) -> str:
    out: list[str] = []
    for span in spans:
        s = getattr(span, "s", "") or ""
        if not s or s == "\n":
            continue
        props = getattr(span, "properties", {}) or {}
        bold = props.get("font-weight") == "bold"
        italic = props.get("font-style") == "italic"
        if bold and italic:
            s = f"***{s}***"
        elif bold:
            s = f"**{s}**"
        elif italic:
            s = f"*{s}*"
        out.append(s)
    return "".join(out).rstrip("\n")
