"""Pack and unpack ``.rmdoc`` archives.

A .rmdoc is a zip with this layout::

    <doc_id>.metadata              JSON: visibleName, parent, type, lastModified, version
    <doc_id>.content               JSON: pages[], fileType, pageCount, ...
    <doc_id>/<page_id>.rm          v6 scene data
    <doc_id>/<page_id>-metadata.json    {"layers":[{"name":"Layer 1"}]}

When updating an existing document, callers must re-use the original
``doc_id`` so reMarkable treats it as an update rather than creating a
duplicate (see CHANGES_FROM_SPEC.md and TODO(open-q1) in cloud.py).
"""

from __future__ import annotations

import io
import json
import time
import uuid
import zipfile
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class RmDocPage:
    page_id: str
    rm_bytes: bytes
    layer_name: str = "Layer 1"


@dataclass
class RmDoc:
    """In-memory representation of a .rmdoc archive."""

    doc_id: str
    visible_name: str
    parent: str = ""
    pages: list[RmDocPage] = field(default_factory=list)
    version: int = 1
    last_modified: int = field(default_factory=lambda: int(time.time() * 1000))


def unpack(archive_path: Path) -> RmDoc:
    """Read a .rmdoc into memory.

    Handles two shapes of .content JSON:
      - Legacy: ``{"pages": ["<page-id>", ...]}``
      - sync15: ``{"cPages": {"pages": [{"id": "<page-id>", ...}, ...]}}``

    Cloud-originated .rmdocs (via rmapi get) use the sync15 shape on
    accounts running that protocol. Uploads we produce may use the legacy
    shape; rmapi accepts both.
    """
    with zipfile.ZipFile(archive_path) as z:
        names = z.namelist()
        meta_name = next(n for n in names if n.endswith(".metadata") and "/" not in n)
        doc_id = meta_name.removesuffix(".metadata")
        meta = json.loads(z.read(meta_name).decode("utf-8"))
        content = json.loads(z.read(f"{doc_id}.content").decode("utf-8"))

        page_ids = _extract_page_ids(content)

        pages: list[RmDocPage] = []
        for page_id in page_ids:
            try:
                rm_bytes = z.read(f"{doc_id}/{page_id}.rm")
            except KeyError:
                # Some sync15 archives omit pages that haven't been opened
                # on the tablet yet; skip silently.
                continue
            try:
                layer_meta = json.loads(
                    z.read(f"{doc_id}/{page_id}-metadata.json").decode("utf-8")
                )
                layer_name = layer_meta["layers"][0]["name"]
            except (KeyError, IndexError, json.JSONDecodeError):
                layer_name = "Layer 1"
            pages.append(RmDocPage(page_id=page_id, rm_bytes=rm_bytes, layer_name=layer_name))

    return RmDoc(
        doc_id=doc_id,
        visible_name=meta.get("visibleName", "Untitled"),
        parent=meta.get("parent", ""),
        pages=pages,
        version=int(meta.get("version", 1)),
        last_modified=int(meta.get("lastModified", time.time() * 1000)),
    )


def _extract_page_ids(content: dict) -> list[str]:
    """Return page IDs from either legacy or sync15 .content shapes."""
    # Legacy flat list of strings
    if "pages" in content and isinstance(content["pages"], list):
        pages = content["pages"]
        if pages and isinstance(pages[0], str):
            return list(pages)
    # sync15 cPages.pages = [{"id": "...", ...}, ...]
    cpages = content.get("cPages") or {}
    for item in cpages.get("pages", []):
        pass  # fall through to list comp
    return [item["id"] for item in cpages.get("pages", []) if isinstance(item, dict) and "id" in item]


def pack(doc: RmDoc, out_path: Path) -> Path:
    """Write a .rmdoc archive in sync15 ``cPages`` format. Returns ``out_path``.

    The original spec assumed a legacy flat ``pages: [id, ...]`` shape, and
    a first pass of the code used that. rmapi accepts it on upload, but
    when the **tablet** later syncs the doc from the cloud it sees a shape
    that doesn't match its sync15 expectations and auto-inserts a blank
    template page at the front. Result: every doc we push shows up on the
    tablet with a blank cover page prepended.

    Fix: write the doc with a proper ``cPages`` block so the tablet takes
    it as-is. Key details (derived from inspecting a tablet-native doc at
    ``/Archive/Fd/Draft``):

      - ``cPages.pages[]`` is a CRDT-ordered list with ``idx.value``
        string keys (fractional-index encoding). Ordering is by that
        string; pages without ``idx`` may render unpredictably.
      - ``template`` may be absent on content pages; the tablet only
        injects a ``Blank`` template page when the list is empty or the
        first page lacks the expected shape.
      - ``originalPageCount: -1`` and ``redirectionPageMap: []`` are
        present in tablet-native docs; omit them on our small docs
        unless we have reason to set them.
    """
    metadata = {
        "deleted": False,
        "lastModified": str(doc.last_modified),
        "lastOpened": "",
        "lastOpenedPage": 0,
        "metadatamodified": False,
        "modified": False,
        "parent": doc.parent,
        "pinned": False,
        "synced": True,
        "type": "DocumentType",
        "version": doc.version,
        "visibleName": doc.visible_name,
    }
    # Fractional-index strings: "ba", "bb", "bc", ... Keeps lexicographic
    # ordering stable as we add more pages.
    def _fidx(n: int) -> str:
        return "b" + chr(ord("a") + n)

    cpages_entries = [
        {
            "id": page.page_id,
            "idx": {"timestamp": "1:1", "value": _fidx(i)},
        }
        for i, page in enumerate(doc.pages)
    ]
    last_opened = doc.pages[-1].page_id if doc.pages else ""
    content = {
        "coverPageNumber": -1,
        "cPages": {
            "lastOpened": {"timestamp": "1:1", "value": last_opened},
            "original": {"timestamp": "0:0", "value": -1},
            "pages": cpages_entries,
            "uuids": [{"first": "00000000-0000-0000-0000-000000000000", "second": 1}],
        },
        "customZoomCenterX": 0,
        "customZoomCenterY": 936,
        "customZoomOrientation": "portrait",
        "customZoomPageHeight": 1872,
        "customZoomPageWidth": 1404,
        "customZoomScale": 1,
        "documentMetadata": {},
        "extraMetadata": {},
        "fileType": "notebook",
        "fontName": "",
        "formatVersion": 2,
        "lineHeight": -1,
        "margins": 100,
        "orientation": "portrait",
        "pageCount": len(doc.pages),
        "pageTags": [],
        "sizeInBytes": str(sum(len(p.rm_bytes) for p in doc.pages)),
        "tags": [],
        "textAlignment": "justify",
        "textScale": 1,
        "zoomMode": "bestFit",
    }

    out_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(f"{doc.doc_id}.metadata", json.dumps(metadata, indent=2))
        z.writestr(f"{doc.doc_id}.content", json.dumps(content, indent=2))
        for page in doc.pages:
            z.writestr(f"{doc.doc_id}/{page.page_id}.rm", page.rm_bytes)
            z.writestr(
                f"{doc.doc_id}/{page.page_id}-metadata.json",
                json.dumps({"layers": [{"name": page.layer_name}]}, indent=2),
            )
    return out_path


def new_page_id() -> str:
    return str(uuid.uuid4())
