"""Multi-page notebook ↔ Markdown page-break sentinel.

Spec originally used ``---`` (Markdown horizontal rule) as the page
separator. That collides with legitimate user content. We use an HTML
comment instead: invisible in rendered Markdown, unique to us, can't be
typed by accident on the tablet.
"""

from __future__ import annotations

import re

PAGE_BREAK = "<!-- rm-sync:page-break -->"
_PAGE_BREAK_RE = re.compile(r"(?m)^[ \t]*<!--\s*rm-sync:page-break\s*-->[ \t]*$")


def join_pages(pages: list[str]) -> str:
    """Combine page Markdown strings into a single document with separators."""
    cleaned = [p.rstrip() + "\n" for p in pages]
    return f"\n{PAGE_BREAK}\n\n".join(cleaned)


def split_pages(markdown: str) -> list[str]:
    """Inverse of :func:`join_pages`. Always returns at least one page."""
    parts = _PAGE_BREAK_RE.split(markdown)
    return [p.strip("\n") + "\n" if p.strip() else "" for p in parts] or [""]
