from rm_sync.conversion.page_splitter import PAGE_BREAK, join_pages, split_pages


def test_join_then_split_round_trips() -> None:
    pages = ["first page\n", "second page\n", "third page\n"]
    joined = join_pages(pages)
    assert PAGE_BREAK in joined
    parts = split_pages(joined)
    assert len(parts) == 3
    assert all("page" in p for p in parts)


def test_split_handles_no_separator() -> None:
    parts = split_pages("just one page\n")
    assert len(parts) == 1


def test_horizontal_rule_is_not_a_page_break() -> None:
    """The reason we use the HTML-comment sentinel: ``---`` must NOT split."""
    md = "para one\n\n---\n\npara two\n"
    parts = split_pages(md)
    assert len(parts) == 1
    assert "---" in parts[0]


def test_empty_input() -> None:
    assert split_pages("") == [""]
