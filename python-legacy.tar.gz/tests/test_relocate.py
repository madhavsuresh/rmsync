"""Tests for the ``rm-sync relocate`` subcommand.

These exercise the move + state-rewrite + config-rewrite logic without
actually talking to launchd. ``_daemon_running`` is patched out so the
refusal path doesn't block the happy path.
"""

from __future__ import annotations

import os
import sqlite3
from pathlib import Path
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from rm_sync import cli as cli_mod


def _seed_state_db(db_path: Path, old: Path) -> None:
    conn = sqlite3.connect(db_path)
    conn.executescript(
        """
        CREATE TABLE schema_version (version INTEGER PRIMARY KEY);
        CREATE TABLE documents (
            doc_id TEXT PRIMARY KEY,
            parent_id TEXT NOT NULL DEFAULT '',
            doc_type TEXT NOT NULL DEFAULT 'DocumentType',
            title TEXT NOT NULL DEFAULT '',
            remote_path TEXT NOT NULL DEFAULT '',
            local_path TEXT NOT NULL,
            remote_version INTEGER NOT NULL DEFAULT 0,
            remote_modified TEXT,
            last_synced_md_hash TEXT,
            last_pull_at TEXT,
            last_push_at TEXT,
            conflict_state TEXT,
            error_state TEXT,
            page_ids TEXT
        );
        CREATE TABLE sync_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts TEXT NOT NULL,
            level TEXT NOT NULL,
            doc_id TEXT,
            message TEXT NOT NULL
        );
        CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        """
    )
    conn.execute("INSERT INTO schema_version VALUES (3)")
    conn.execute(
        "INSERT INTO documents(doc_id, local_path) VALUES (?,?)",
        ("d1", str(old / "alpha.md")),
    )
    conn.execute(
        "INSERT INTO documents(doc_id, local_path) VALUES (?,?)",
        ("d2", str(old / "sub" / "beta.md")),
    )
    conn.commit()
    conn.close()


def test_relocate_moves_files_and_rewrites_state_and_config(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    old = tmp_path / "old-sync"
    new = tmp_path / "new-sync"
    old.mkdir()
    (old / "alpha.md").write_text("a\n")
    (old / "sub").mkdir()
    (old / "sub" / "beta.md").write_text("b\n")

    state_dir = tmp_path / "state"
    state_dir.mkdir()
    db = state_dir / "state.db"
    _seed_state_db(db, old)

    cfg_path = tmp_path / "config.toml"
    cfg_path.write_text(f'sync_dir = "{old}"\nremote_folder = "Writing"\n')

    # Point all the config constants at our fixtures.
    monkeypatch.setenv("RM_SYNC_CONFIG", str(cfg_path))
    monkeypatch.setenv("RM_SYNC_STATE_DIR", str(state_dir))

    # Reload config + cli modules so they pick up the new env vars.
    import importlib

    from rm_sync import config as config_mod

    importlib.reload(config_mod)
    importlib.reload(cli_mod)

    with patch.object(cli_mod, "_stop_agent", return_value=False), patch.object(
        cli_mod, "_start_agent", return_value=True
    ):
        runner = CliRunner()
        result = runner.invoke(cli_mod.main, ["relocate", str(new)])
    assert result.exit_code == 0, result.output

    # Files moved
    assert (new / "alpha.md").read_text() == "a\n"
    assert (new / "sub" / "beta.md").read_text() == "b\n"
    assert not old.exists() or not any(old.iterdir())

    # State rewritten
    conn = sqlite3.connect(db)
    conn.row_factory = sqlite3.Row
    rows = {r["doc_id"]: r["local_path"] for r in conn.execute("SELECT * FROM documents")}
    conn.close()
    assert rows["d1"] == str(new / "alpha.md")
    assert rows["d2"] == str(new / "sub" / "beta.md")

    # Config rewritten
    assert f'sync_dir = "{new}"' in cfg_path.read_text()


def test_relocate_stops_and_restarts_running_daemon(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """When the daemon is loaded, relocate should bootout + bootstrap it."""
    old = tmp_path / "old"
    old.mkdir()
    (old / "note.md").write_text("n\n")
    cfg_path = tmp_path / "config.toml"
    cfg_path.write_text(f'sync_dir = "{old}"\n')
    state_dir = tmp_path / "state"
    state_dir.mkdir()

    monkeypatch.setenv("RM_SYNC_CONFIG", str(cfg_path))
    monkeypatch.setenv("RM_SYNC_STATE_DIR", str(state_dir))

    import importlib

    from rm_sync import config as config_mod

    importlib.reload(config_mod)
    importlib.reload(cli_mod)

    with (
        patch.object(cli_mod, "_stop_agent", return_value=True) as stop,
        patch.object(cli_mod, "_start_agent", return_value=True) as start,
    ):
        runner = CliRunner()
        result = runner.invoke(
            cli_mod.main, ["relocate", str(tmp_path / "new")]
        )
    assert result.exit_code == 0, result.output
    assert stop.called
    assert start.called
    assert "stopped launchd agent" in result.output
    assert "started launchd agent" in result.output


def test_relocate_keep_stopped_skips_restart(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    old = tmp_path / "old"
    old.mkdir()
    (old / "note.md").write_text("n\n")
    cfg_path = tmp_path / "config.toml"
    cfg_path.write_text(f'sync_dir = "{old}"\n')
    state_dir = tmp_path / "state"
    state_dir.mkdir()

    monkeypatch.setenv("RM_SYNC_CONFIG", str(cfg_path))
    monkeypatch.setenv("RM_SYNC_STATE_DIR", str(state_dir))

    import importlib

    from rm_sync import config as config_mod

    importlib.reload(config_mod)
    importlib.reload(cli_mod)

    with (
        patch.object(cli_mod, "_stop_agent", return_value=True),
        patch.object(cli_mod, "_start_agent", return_value=True) as start,
    ):
        runner = CliRunner()
        result = runner.invoke(
            cli_mod.main,
            ["relocate", str(tmp_path / "new"), "--keep-stopped"],
        )
    assert result.exit_code == 0
    assert not start.called
    assert "Agent left stopped" in result.output
