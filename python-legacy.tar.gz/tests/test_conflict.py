from pathlib import Path

from rm_sync.conflict import (
    conflict_path_for,
    has_unresolved_conflict_file,
    write_conflict,
)


def test_conflict_path_appends_suffix(tmp_path: Path) -> None:
    md = tmp_path / "note.md"
    assert conflict_path_for(md).name == "note.md.conflict"


def test_write_conflict_contains_markers(tmp_path: Path) -> None:
    md = tmp_path / "note.md"
    md.write_text("local content\n")
    cp = write_conflict(md, local="local content\n", remote="remote content\n")
    body = cp.read_text()
    assert "<<<<<<< local" in body
    assert "=======" in body
    assert ">>>>>>> remote" in body
    # Live file is untouched
    assert md.read_text() == "local content\n"


def test_has_unresolved_conflict_file_true_then_false(tmp_path: Path) -> None:
    md = tmp_path / "note.md"
    assert not has_unresolved_conflict_file(md)
    md.write_text("hi")
    write_conflict(md, local="hi", remote="bye")
    assert has_unresolved_conflict_file(md)
    conflict_path_for(md).unlink()
    assert not has_unresolved_conflict_file(md)
