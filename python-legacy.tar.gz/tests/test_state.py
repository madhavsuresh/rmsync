from pathlib import Path

import pytest

from rm_sync.state import Document, open_state


@pytest.mark.asyncio
async def test_upsert_and_get(tmp_state_db: Path) -> None:
    async with open_state(tmp_state_db) as s:
        d = Document(
            doc_id="abc",
            parent_id="",
            doc_type="DocumentType",
            title="Hello",
            remote_path="Writing/Hello",
            local_path="/tmp/hello.md",
            remote_version=1,
        )
        await s.upsert(d)
        got = await s.get("abc")
        assert got is not None
        assert got.title == "Hello"


@pytest.mark.asyncio
async def test_mark_pulled_clears_error(tmp_state_db: Path) -> None:
    async with open_state(tmp_state_db) as s:
        d = Document(
            doc_id="x",
            parent_id="",
            doc_type="DocumentType",
            title="t",
            remote_path="Writing/t",
            local_path="/tmp/t.md",
            remote_version=1,
            error_state="parse_failed",
        )
        await s.upsert(d)
        await s.mark_pulled("x", version=2, md_hash="abcd")
        got = await s.get("x")
        assert got is not None
        assert got.error_state is None
        assert got.last_synced_md_hash == "abcd"
        assert got.remote_version == 2


@pytest.mark.asyncio
async def test_conflict_state_roundtrip(tmp_state_db: Path) -> None:
    async with open_state(tmp_state_db) as s:
        await s.upsert(
            Document(
                doc_id="c",
                parent_id="",
                doc_type="DocumentType",
                title="t",
                remote_path="Writing/t",
                local_path="/tmp/t.md",
                remote_version=1,
            )
        )
        await s.set_conflict("c", "unresolved")
        got = await s.get("c")
        assert got and got.conflict_state == "unresolved"
        await s.set_conflict("c", None)
        got = await s.get("c")
        assert got and got.conflict_state is None
