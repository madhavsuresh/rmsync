"""Shared pytest fixtures."""

import os
import tempfile
from pathlib import Path

import pytest

# Point state and config at temp locations so tests don't touch real $HOME.
_TMP = Path(tempfile.mkdtemp(prefix="rmsync-test-"))
os.environ.setdefault("RM_SYNC_STATE_DIR", str(_TMP / "state"))
os.environ.setdefault("RM_SYNC_LOG_DIR", str(_TMP / "logs"))
os.environ.setdefault("RM_SYNC_CONFIG", str(_TMP / "config.toml"))


@pytest.fixture()
def tmp_state_db(tmp_path: Path) -> Path:
    return tmp_path / "state.db"
