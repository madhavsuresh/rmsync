import time

from rm_sync.echo_fence import EchoFence


def test_marked_path_is_recent() -> None:
    f = EchoFence(window_seconds=2.0)
    f.mark("/tmp/foo.md")
    assert f.is_recent("/tmp/foo.md")


def test_unmarked_path_is_not_recent() -> None:
    f = EchoFence(window_seconds=2.0)
    assert not f.is_recent("/tmp/foo.md")


def test_expires_after_window() -> None:
    f = EchoFence(window_seconds=0.05)
    f.mark("/tmp/x.md")
    time.sleep(0.1)
    assert not f.is_recent("/tmp/x.md")


def test_garbage_collection() -> None:
    f = EchoFence(window_seconds=0.05)
    for i in range(50):
        f.mark(f"/tmp/{i}.md")
    time.sleep(0.1)
    f.mark("/tmp/keep.md")
    # After mark, GC should have cleared the stale entries.
    assert len(f._stamps) == 1
