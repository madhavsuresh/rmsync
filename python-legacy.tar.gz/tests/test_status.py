"""Tests for the status.json snapshot writer."""

from __future__ import annotations

import asyncio
import json
from pathlib import Path

import pytest

from rm_sync.config import Config, LogConfig
from rm_sync.state import Document, open_state
from rm_sync.status import StatusWriter, read_status


def _make_cfg(tmp_path: Path) -> Config:
    return Config(
        sync_dir=tmp_path / "sync",
        remote_folder="Writing",
        log=LogConfig(level="INFO"),
    )


@pytest.mark.asyncio
async def test_status_writer_snapshots_state(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    # Redirect STATUS_JSON_PATH to tmp.
    status_path = tmp_path / "status.json"
    import rm_sync.config as cfg_mod
    import rm_sync.status as status_mod

    monkeypatch.setattr(cfg_mod, "STATUS_JSON_PATH", status_path)
    monkeypatch.setattr(status_mod, "STATUS_JSON_PATH", status_path)

    db_path = tmp_path / "state.db"
    async with open_state(db_path) as state:
        await state.upsert(
            Document(
                doc_id="d1",
                parent_id="",
                doc_type="DocumentType",
                title="a",
                remote_path="/Writing/a",
                local_path=str(tmp_path / "a.md"),
                remote_version=0,
                last_synced_md_hash="abc",
                last_pull_at="2026-04-18T00:00:00Z",
            )
        )
        await state.upsert(
            Document(
                doc_id="d2",
                parent_id="",
                doc_type="DocumentType",
                title="b",
                remote_path="/Writing/b",
                local_path=str(tmp_path / "b.md"),
                remote_version=0,
                conflict_state="unresolved",
            )
        )

        cfg = _make_cfg(tmp_path)
        writer = StatusWriter(state, cfg, queue=asyncio.Queue(), interval_seconds=60)
        await writer._tick("idle")

    payload = json.loads(status_path.read_text())
    assert payload["schema_version"] == 1
    assert payload["state"] == "idle"
    assert payload["tracked_docs"] == 2
    assert payload["conflicts"] == 1
    assert payload["errors"] == 0
    assert payload["remote_folder"] == "Writing"
    assert payload["last_pull_at"] == "2026-04-18T00:00:00Z"
    assert "pid" in payload


@pytest.mark.asyncio
async def test_status_writer_reflects_paused_setting(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Schema v4: paused lives in settings.paused, not a sentinel file."""
    import rm_sync.config as cfg_mod
    import rm_sync.status as status_mod

    status_path = tmp_path / "status.json"
    monkeypatch.setattr(cfg_mod, "STATUS_JSON_PATH", status_path)
    monkeypatch.setattr(status_mod, "STATUS_JSON_PATH", status_path)

    async with open_state(tmp_path / "state.db") as state:
        await state.set_paused(True)
        writer = StatusWriter(state, _make_cfg(tmp_path), interval_seconds=60)
        await writer._tick("idle")

    payload = json.loads(status_path.read_text())
    assert payload["state"] == "paused"
    assert payload["paused"] is True


def read_status_patched(path: Path) -> dict:
    return json.loads(path.read_text())


@pytest.mark.asyncio
async def test_read_status_returns_none_when_missing(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import rm_sync.status as status_mod

    monkeypatch.setattr(status_mod, "STATUS_JSON_PATH", tmp_path / "absent.json")
    assert read_status() is None
