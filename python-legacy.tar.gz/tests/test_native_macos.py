"""macOS-only tests for xattr helpers.

Skipped on non-Darwin hosts. The tests create a tmpfile and verify xattrs
round-trip — if the fs strips xattrs (rare in a TemporaryDirectory on
APFS, but possible), the test also skips gracefully.
"""

from __future__ import annotations

import plistlib
import sys
from pathlib import Path

import pytest

pytestmark = pytest.mark.skipif(sys.platform != "darwin", reason="macOS-only")


def test_apply_metadata_writes_expected_xattrs(tmp_path: Path) -> None:
    from rm_sync.native.macos import FileMetadata, _getxattr, apply_metadata

    p = tmp_path / "note.md"
    p.write_text("x\n")

    meta = FileMetadata(
        doc_id="abc-123",
        remote_path="/Writing/foo",
        remote_modified="2026-04-17T12:00:00Z",
        page_ids=["p-1", "p-2"],
    )
    apply_metadata(p, meta)

    assert _getxattr(p, "rm-sync.doc_id") == b"abc-123"
    assert _getxattr(p, "rm-sync.remote_path") == b"/Writing/foo"
    assert _getxattr(p, "rm-sync.remote_modified") == b"2026-04-17T12:00:00Z"
    assert _getxattr(p, "rm-sync.page_ids") == b'["p-1", "p-2"]'

    wf_raw = _getxattr(p, "com.apple.metadata:kMDItemWhereFroms")
    wf = plistlib.loads(wf_raw)
    assert wf == ["reMarkable Cloud", "/Writing/foo"]

    kind_raw = _getxattr(p, "com.apple.metadata:kMDItemKind")
    assert plistlib.loads(kind_raw) == "reMarkable Notebook"

    tags_raw = _getxattr(p, "com.apple.metadata:_kMDItemUserTags")
    tags = plistlib.loads(tags_raw)
    assert tags == ["reMarkable\n5"]


def test_apply_metadata_skips_falsy_fields(tmp_path: Path) -> None:
    from rm_sync.native.macos import FileMetadata, _getxattr, apply_metadata

    p = tmp_path / "note.md"
    p.write_text("x\n")
    apply_metadata(p, FileMetadata())  # everything None

    # The core where-froms/kind/tag still get written (they don't need meta)
    assert _getxattr(p, "com.apple.metadata:kMDItemKind")
    # But the rm-sync.* xattrs should NOT be present
    with pytest.raises(OSError):
        _getxattr(p, "rm-sync.doc_id")


def test_atomic_write_text_with_metadata_integration(tmp_path: Path) -> None:
    from rm_sync.native.macos import FileMetadata, _getxattr
    from rm_sync.paths import atomic_write_text

    p = tmp_path / "note.md"
    atomic_write_text(
        p,
        "hello\n",
        metadata=FileMetadata(doc_id="xyz", remote_path="/Writing/x"),
    )
    assert p.read_text() == "hello\n"
    assert _getxattr(p, "rm-sync.doc_id") == b"xyz"


def test_read_doc_id_round_trip(tmp_path: Path) -> None:
    from rm_sync.native.macos import FileMetadata, apply_metadata, read_doc_id

    p = tmp_path / "note.md"
    p.write_text("x\n")
    apply_metadata(p, FileMetadata(doc_id="deadbeef"))
    assert read_doc_id(p) == "deadbeef"


def test_read_doc_id_missing(tmp_path: Path) -> None:
    from rm_sync.native.macos import read_doc_id

    p = tmp_path / "plain.md"
    p.write_text("x\n")
    assert read_doc_id(p) is None
