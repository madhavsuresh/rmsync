"""Tests for the IPC server and StateBus.

Spins up the server in-process, connects a client, exercises
hello / get_status / pause / broadcast. Synchronous client lives in
``ipc_client`` and is tested separately below.
"""

from __future__ import annotations

import asyncio
import json
import os
import socket
import tempfile
from pathlib import Path

import pytest

from rm_sync.ipc import CommandRegistry, IPCServer, StateBus
from rm_sync.ipc_client import IPCUnavailable, request


@pytest.fixture
def socket_path() -> Path:
    # AF_UNIX paths are capped at 104 bytes on macOS; pytest's tmp_path
    # (/private/var/folders/...) easily exceeds that. Stay under /tmp.
    d = Path(tempfile.mkdtemp(prefix="rmipc-", dir="/tmp"))
    p = d / "s"
    yield p
    try:
        p.unlink()
    except OSError:
        pass
    try:
        d.rmdir()
    except OSError:
        pass


@pytest.mark.asyncio
async def test_hello_on_connect(socket_path: Path) -> None:
    bus = StateBus()
    registry = CommandRegistry()
    await bus.update(state="idle", tracked_docs=3)

    server = IPCServer(socket_path, bus, registry)
    await server.start()
    try:
        reader, writer = await asyncio.open_unix_connection(str(socket_path))
        line = await reader.readline()
        frame = json.loads(line)
        assert frame["type"] == "hello"
        assert frame["status"]["state"] == "idle"
        assert frame["status"]["tracked_docs"] == 3
        writer.close()
        await writer.wait_closed()
    finally:
        await server.stop()


@pytest.mark.asyncio
async def test_command_dispatch_and_ack(socket_path: Path) -> None:
    bus = StateBus()
    registry = CommandRegistry()
    received: list[dict] = []

    @registry.register("ping")
    async def _ping(frame):
        received.append(frame)
        return {"pong": True}

    server = IPCServer(socket_path, bus, registry)
    await server.start()
    try:
        reader, writer = await asyncio.open_unix_connection(str(socket_path))
        await reader.readline()  # hello

        req = {"id": "abc", "type": "ping", "foo": 1}
        writer.write((json.dumps(req) + "\n").encode())
        await writer.drain()

        ack = json.loads(await reader.readline())
        assert ack == {"type": "ack", "id": "abc", "ok": True, "pong": True}
        assert received == [req]

        writer.close()
        await writer.wait_closed()
    finally:
        await server.stop()


@pytest.mark.asyncio
async def test_unknown_command_returns_error(socket_path: Path) -> None:
    bus = StateBus()
    registry = CommandRegistry()
    server = IPCServer(socket_path, bus, registry)
    await server.start()
    try:
        reader, writer = await asyncio.open_unix_connection(str(socket_path))
        await reader.readline()  # hello
        writer.write(b'{"id":"1","type":"nope"}\n')
        await writer.drain()
        ack = json.loads(await reader.readline())
        assert ack["type"] == "ack"
        assert ack["ok"] is False
        assert "unknown command" in ack["error"]
        writer.close()
        await writer.wait_closed()
    finally:
        await server.stop()


@pytest.mark.asyncio
async def test_broadcast_delivered_to_all_clients(socket_path: Path) -> None:
    bus = StateBus()
    registry = CommandRegistry()
    server = IPCServer(socket_path, bus, registry)
    await server.start()
    try:
        r1, w1 = await asyncio.open_unix_connection(str(socket_path))
        r2, w2 = await asyncio.open_unix_connection(str(socket_path))
        await r1.readline(); await r2.readline()  # hellos

        await bus.update(state="syncing", queue_depth=5)

        f1 = json.loads(await asyncio.wait_for(r1.readline(), timeout=1))
        f2 = json.loads(await asyncio.wait_for(r2.readline(), timeout=1))
        for f in (f1, f2):
            assert f["type"] == "status"
            assert f["state"] == "syncing"
            assert f["queue_depth"] == 5

        w1.close(); w2.close()
        await w1.wait_closed(); await w2.wait_closed()
    finally:
        await server.stop()


@pytest.mark.asyncio
async def test_socket_has_owner_only_permissions(socket_path: Path) -> None:
    bus = StateBus()
    registry = CommandRegistry()
    server = IPCServer(socket_path, bus, registry)
    await server.start()
    try:
        mode = socket_path.stat().st_mode & 0o777
        assert mode == 0o600
    finally:
        await server.stop()


@pytest.mark.asyncio
async def test_stale_socket_file_is_unlinked(socket_path: Path) -> None:
    # Leave a plain file where the socket should go.
    socket_path.write_bytes(b"stale")
    bus = StateBus()
    registry = CommandRegistry()
    server = IPCServer(socket_path, bus, registry)
    await server.start()
    try:
        # Should have replaced the stale file with a working socket.
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.connect(str(socket_path))
        s.close()
    finally:
        await server.stop()


# ---- sync client --------------------------------------------------------


def test_ipc_client_unavailable_when_no_socket(tmp_path: Path, monkeypatch) -> None:
    missing = tmp_path / "missing.sock"
    import rm_sync.ipc_client as client_mod

    monkeypatch.setattr(client_mod, "IPC_SOCKET_PATH", missing)
    with pytest.raises(IPCUnavailable):
        request("get_status", timeout=0.1)


@pytest.mark.asyncio
async def test_sync_client_round_trip(socket_path: Path, monkeypatch) -> None:
    """Spin up the server in a background task, use the sync client
    (which blocks on socket IO) via asyncio.to_thread."""
    bus = StateBus()
    registry = CommandRegistry()

    @registry.register("pause")
    async def _pause(_frame):
        await bus.update(state="paused", paused=True)
        return None

    import rm_sync.ipc_client as client_mod

    monkeypatch.setattr(client_mod, "IPC_SOCKET_PATH", socket_path)

    server = IPCServer(socket_path, bus, registry)
    await server.start()
    try:
        result = await asyncio.to_thread(request, "pause", 2.0)
        assert result["ok"] is True
    finally:
        await server.stop()
