"""Verify watcher._should_ignore rules, including Dropbox conflict names."""

from __future__ import annotations

from pathlib import Path

from rm_sync.watcher import _should_ignore


def _ign(name: str, sync_dir: Path) -> bool:
    return _should_ignore(str(sync_dir / name), sync_dir)


def test_ignores_dropbox_conflict_copy(tmp_path: Path) -> None:
    # Canonical Dropbox conflict filename.
    assert _ign("foo (Mac mini's conflicted copy 2026-04-17).md", tmp_path)
    # Upper-case variant.
    assert _ign("bar (Alice's CONFLICTED COPY 2024-12-01 1).md", tmp_path)
    # With trailing revision number.
    assert _ign("baz (machine's conflicted copy 2025-01-01 3).md", tmp_path)


def test_accepts_normal_md(tmp_path: Path) -> None:
    assert not _ign("note.md", tmp_path)
    assert not _ign("my document with parens (yes).md", tmp_path)


def test_ignores_dotfiles_and_tmp(tmp_path: Path) -> None:
    assert _ign(".DS_Store", tmp_path)
    assert _ign(".something.md", tmp_path)
    assert _ign("note.md.tmp", tmp_path)
    assert _ign("note.md.conflict", tmp_path)


def test_ignores_non_md_suffixes(tmp_path: Path) -> None:
    assert _ign("thing.txt", tmp_path)
    assert _ign("thing.pdf", tmp_path)


def test_ignores_subtree_hidden_dirs(tmp_path: Path) -> None:
    # anything under .rm-sync-trash, .git, .obsidian
    deep = tmp_path / ".rm-sync-trash" / "old.md"
    assert _should_ignore(str(deep), tmp_path)
    deep2 = tmp_path / ".git" / "hooks" / "x.md"
    assert _should_ignore(str(deep2), tmp_path)
