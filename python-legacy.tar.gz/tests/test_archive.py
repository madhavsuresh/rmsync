"""Round-trip a synthetic .rmdoc through pack → unpack."""

from pathlib import Path

from rm_sync.conversion.archive import RmDoc, RmDocPage, new_page_id, pack, unpack


def test_pack_unpack_preserves_pages(tmp_path: Path) -> None:
    pages = [
        RmDocPage(page_id=new_page_id(), rm_bytes=b"\x00page-one"),
        RmDocPage(page_id=new_page_id(), rm_bytes=b"\x00page-two"),
    ]
    doc = RmDoc(
        doc_id="doc-1234",
        visible_name="My Notebook",
        parent="",
        pages=pages,
        version=3,
    )
    out = tmp_path / "doc.rmdoc"
    pack(doc, out)
    assert out.exists()

    rt = unpack(out)
    assert rt.doc_id == "doc-1234"
    assert rt.visible_name == "My Notebook"
    assert rt.version == 3
    assert len(rt.pages) == 2
    assert rt.pages[0].rm_bytes == b"\x00page-one"
    assert rt.pages[1].rm_bytes == b"\x00page-two"


def test_packed_content_uses_sync15_cpages_shape(tmp_path):
    """We must pack with ``cPages`` + ``coverPageNumber: -1``.

    Legacy flat ``pages: [id, ...]`` causes the tablet to prepend a blank
    ``template: Blank`` page when it syncs the doc. sync15-shaped
    ``cPages.pages[{id, idx}]`` is taken as-is.
    """
    import json
    import zipfile

    page_id = new_page_id()
    doc = RmDoc(
        doc_id="abc",
        visible_name="N",
        pages=[RmDocPage(page_id=page_id, rm_bytes=b"p")],
    )
    out = tmp_path / "x.rmdoc"
    pack(doc, out)
    with zipfile.ZipFile(out) as z:
        content = json.loads(z.read("abc.content").decode())
    assert content["coverPageNumber"] == -1
    assert content["pageCount"] == 1
    assert "cPages" in content
    assert len(content["cPages"]["pages"]) == 1
    entry = content["cPages"]["pages"][0]
    assert entry["id"] == page_id
    assert "idx" in entry and "value" in entry["idx"]
    # No ``template`` field on content pages; its presence with value
    # "Blank" is what the tablet injects, and we must NOT mirror that.
    assert "template" not in entry
