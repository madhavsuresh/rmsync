"""Strategy A round-trip: plain text → .rm → plain text.

Skips when rmscene isn't installed in the test environment, since the
scaffold ships before the venv is built.
"""

import pytest

pytest.importorskip("rmscene")

from rm_sync.conversion.md_to_rm import page_native_plain  # noqa: E402
from rm_sync.conversion.rm_to_md import page_to_markdown  # noqa: E402


def test_plain_text_round_trips() -> None:
    text = "first line\nsecond line\nthird line\n"
    rm_bytes = page_native_plain(text)
    out = page_to_markdown(rm_bytes)
    # rmscene's plain writer normalizes; assert content survives line by line.
    for line in ("first line", "second line", "third line"):
        assert line in out


def test_empty_input_does_not_crash() -> None:
    rm_bytes = page_native_plain("")
    # Empty input → empty page is OK, just don't crash on parse.
    page_to_markdown(rm_bytes)
