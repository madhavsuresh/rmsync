from pathlib import Path

import pytest

from rm_sync.paths import (
    atomic_write_text,
    case_only_rename,
    disambiguate,
    normalize_for_compare,
    sanitize_segment,
)


@pytest.mark.parametrize(
    "raw,expected",
    [
        ("foo/bar", "foo_bar"),
        ("foo:bar", "foo_bar"),
        ("foo.", "foo"),
        ("   ", "untitled"),
        ("", "untitled"),
        ("CON", "_CON_"),
        ("hello world", "hello world"),
        ("normal_name", "normal_name"),
    ],
)
def test_sanitize_known_inputs(raw: str, expected: str) -> None:
    assert sanitize_segment(raw) == expected


def test_sanitize_collapses_underscores() -> None:
    assert sanitize_segment("a///b") == "a_b"


def test_sanitize_truncates() -> None:
    out = sanitize_segment("x" * 300)
    assert len(out) == 200


def test_disambiguate_no_collision() -> None:
    assert disambiguate("foo.md", set()) == "foo.md"


def test_disambiguate_with_collision() -> None:
    out = disambiguate("foo.md", {"foo.md"})
    assert out != "foo.md"
    assert out.endswith(".md")


def test_normalize_for_compare_nfd_to_nfc() -> None:
    nfd = "cafe\u0301"  # é as combining sequence
    nfc = "café"
    assert normalize_for_compare(nfd) == normalize_for_compare(nfc)


def test_atomic_write_text_creates_parents(tmp_path: Path) -> None:
    p = tmp_path / "deep" / "nested" / "file.md"
    atomic_write_text(p, "hello\n")
    assert p.read_text() == "hello\n"
    # No leftover .tmp
    assert not (p.parent / "file.md.tmp").exists()


def test_case_only_rename_on_apfs(tmp_path: Path) -> None:
    src = tmp_path / "Notes.md"
    src.write_text("x")
    dst = tmp_path / "notes.md"
    case_only_rename(src, dst)
    # On case-insensitive APFS both names resolve to the same file but the
    # canonical name is now lowercase.
    assert dst.exists()
    # Inspect actual on-disk casing via parent.iterdir
    names = [p.name for p in tmp_path.iterdir()]
    assert "notes.md" in names
