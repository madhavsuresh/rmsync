"""End-to-end against rmfakecloud running in Docker.

Skipped unless ``RM_SYNC_FAKECLOUD_URL`` is set in the environment. CI
should bring up rmfakecloud (https://github.com/ddvk/rmfakecloud) in a
sidecar container and export the URL.

Test plan:
  - Pre-populate Writing/ on the fake cloud with one notebook.
  - Boot the daemon pointed at the fake cloud (via RMAPI_HOST).
  - Verify a local .md appears in sync_dir within 2× poll interval.
  - Edit the .md, verify the cloud version increments.
  - Make a conflicting cloud edit, verify .conflict file is written.
"""

import os

import pytest

pytestmark = pytest.mark.skipif(
    not os.environ.get("RM_SYNC_FAKECLOUD_URL"),
    reason="set RM_SYNC_FAKECLOUD_URL to run integration tests",
)


def test_initial_pull_creates_local_files() -> None:
    pytest.skip("TODO: implement once rmfakecloud harness is wired up")


def test_local_edit_propagates_to_cloud() -> None:
    pytest.skip("TODO: gated on open-q1 verification (push path)")


def test_simultaneous_edit_produces_conflict_file() -> None:
    pytest.skip("TODO: gated on open-q1 verification (push path)")
