#!/usr/bin/env bash
# rm-sync installer for macOS.
# Idempotent: re-running upgrades the venv and re-renders the plist.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

PY=${PYTHON:-python3}
if ! "$PY" -c 'import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)'; then
    echo "ERROR: Python 3.11+ required (found $($PY --version 2>&1))" >&2
    exit 1
fi

if ! command -v rmapi >/dev/null; then
    echo "ERROR: rmapi not on PATH. Install with: brew install io41/tap/rmapi" >&2
    exit 1
fi

VENV="$SCRIPT_DIR/.venv"
if [[ ! -d "$VENV" ]]; then
    echo "Creating virtualenv at $VENV"
    "$PY" -m venv "$VENV"
fi

# shellcheck disable=SC1091
source "$VENV/bin/activate"
pip install --upgrade pip >/dev/null
pip install -e . >/dev/null

CONFIG_DIR="$HOME/.config/rm-sync"
STATE_DIR="$HOME/Library/Application Support/rm-sync"
LOG_DIR="$HOME/Library/Logs/rm-sync"
AGENT_DIR="$HOME/Library/LaunchAgents"
mkdir -p "$CONFIG_DIR" "$STATE_DIR" "$LOG_DIR" "$AGENT_DIR"

if [[ ! -f "$CONFIG_DIR/config.toml" ]]; then
    echo "Writing default config to $CONFIG_DIR/config.toml — edit it before running the daemon"
    cat > "$CONFIG_DIR/config.toml" <<EOF
sync_dir      = "$HOME/rm-sync-writing"
remote_folder = "Writing"

worker_pool_size               = 3
poll_interval_seconds          = 30
poll_active_interval_seconds   = 15
poll_idle_interval_seconds     = 120
debounce_seconds               = 2.0
echo_fence_seconds             = 5.0
retry_max_attempts             = 3

push_strategy = "native_plain"

backup_snapshots_to_keep = 30
dry_run                  = false

[log]
level = "INFO"
EOF
fi

PLIST="$AGENT_DIR/com.user.rmsync.plist"
PYTHON_BIN="$VENV/bin/python"
sed \
    -e "s|__PYTHON_BIN__|$PYTHON_BIN|g" \
    -e "s|__HOME__|$HOME|g" \
    "$SCRIPT_DIR/scripts/com.user.rmsync.plist.template" > "$PLIST"

# Re-bootstrap the agent so it picks up the new plist
launchctl bootout "gui/$(id -u)/com.user.rmsync" 2>/dev/null || true
launchctl bootstrap "gui/$(id -u)" "$PLIST"

# ── Menu bar app (optional; requires Swift toolchain) ────────────────────
MENUBAR_PLIST="$AGENT_DIR/com.user.rmsync.menubar.plist"
if command -v swift >/dev/null; then
    echo "Building menu bar app..."
    (cd "$SCRIPT_DIR/menubar" && swift build -c release >/dev/null)
    MENUBAR_BIN="$SCRIPT_DIR/menubar/.build/release/rmsync-menubar"
    if [[ -x "$MENUBAR_BIN" ]]; then
        sed \
            -e "s|__MENUBAR_BIN__|$MENUBAR_BIN|g" \
            -e "s|__HOME__|$HOME|g" \
            "$SCRIPT_DIR/scripts/com.user.rmsync.menubar.plist.template" > "$MENUBAR_PLIST"
        launchctl bootout "gui/$(id -u)/com.user.rmsync.menubar" 2>/dev/null || true
        launchctl bootstrap "gui/$(id -u)" "$MENUBAR_PLIST"
        echo "  menu bar app installed at $MENUBAR_BIN"
    else
        echo "  menu bar build failed; skipping"
    fi
else
    echo "Swift not found; skipping menu bar app. Install Xcode command-line tools"
    echo "(xcode-select --install), then re-run this installer."
fi

echo
echo "rm-sync installed."
echo "  config:  $CONFIG_DIR/config.toml"
echo "  state:   $STATE_DIR"
echo "  logs:    $LOG_DIR"
echo "  plist:   $PLIST"
[[ -f "$MENUBAR_PLIST" ]] && echo "  menu:    $MENUBAR_PLIST"
echo
echo "Run 'rm-sync doctor' to verify, or 'rm-sync logs -f' to tail the daemon."
