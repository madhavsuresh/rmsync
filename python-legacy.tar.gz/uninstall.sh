#!/usr/bin/env bash
# Removes the launchd agent. Leaves config, state, and logs in place by default.
# Pass --purge to wipe state and config too.
set -euo pipefail

PLIST="$HOME/Library/LaunchAgents/com.user.rmsync.plist"
MENUBAR_PLIST="$HOME/Library/LaunchAgents/com.user.rmsync.menubar.plist"

launchctl bootout "gui/$(id -u)/com.user.rmsync" 2>/dev/null || true
launchctl bootout "gui/$(id -u)/com.user.rmsync.menubar" 2>/dev/null || true
rm -f "$PLIST" "$MENUBAR_PLIST"

if [[ "${1:-}" == "--purge" ]]; then
    rm -rf "$HOME/Library/Application Support/rm-sync"
    rm -rf "$HOME/.config/rm-sync"
    rm -rf "$HOME/Library/Logs/rm-sync"
    echo "rm-sync agent removed and state purged."
else
    echo "rm-sync agent removed. State preserved at $HOME/Library/Application Support/rm-sync"
    echo "Run with --purge to remove state, config, and logs as well."
fi
